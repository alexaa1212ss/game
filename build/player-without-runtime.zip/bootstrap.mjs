// Installed, stable bootstrap. No keys or gameplay administration are embedded.
import {readFileSync,writeFileSync,mkdirSync,appendFileSync} from 'node:fs';
import {createHash,createPublicKey,verify} from 'node:crypto';
import path from 'node:path';import {pathToFileURL} from 'node:url';
const root=path.resolve(process.argv[2]),key=readFileSync(path.join(root,'release-public.pem'),'utf8');
const pointerFile=path.join(root,'installed.json');let pointer=JSON.parse(readFileSync(pointerFile,'utf8'));
const select=version=>{
 if(!/^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(version))throw Error('Invalid installed version.');
 const folder=path.join(root,'versions',version),m=JSON.parse(readFileSync(path.join(folder,'trusted-release.json'),'utf8')),r=m.release;
 if(r?.product!=='RebornPlayer'||r.version!==version||!Array.isArray(r.files)||!verify(null,Buffer.from(JSON.stringify(r)),createPublicKey(key),Buffer.from(m.signature??'','base64')))throw Error('Installed release signature invalid.');
 for(const f of r.files){if(!/^[a-zA-Z0-9_. /-]+$/.test(f.path)||f.path.startsWith('/')||f.path.split('/').some(p=>!p||p==='.'||p==='..'))throw Error('Invalid signed file path.');const bytes=readFileSync(path.join(folder,f.path));if(bytes.length!==f.bytes||createHash('sha256').update(bytes).digest('hex')!==f.sha256)throw Error('Installed file verification failed: '+f.path);}
 return folder;
};
const log=message=>{const folder=path.join(process.env.LOCALAPPDATA??root,'CavegameReborn');mkdirSync(folder,{recursive:true});appendFileSync(path.join(folder,'launcher-errors.log'),new Date().toISOString()+' '+message+'\n');};
try{
 let folder;try{folder=select(pointer.current);}catch(error){if(!pointer.pending||!pointer.previous)throw error;folder=select(pointer.previous);pointer={format:1,current:pointer.previous,previous:null};writeFileSync(pointerFile,JSON.stringify(pointer));log('Incomplete update rolled back: '+error.message);}
 process.env.CAVEGAME_INSTALL_ROOT=root;process.env.CAVEGAME_APP_VERSION=pointer.current;
 const {ReleaseUpdater}=await import(pathToFileURL(path.join(folder,'app/src/online/update.mjs'))),updater=new ReleaseUpdater({directory:root,product:'RebornPlayer'});
 const {fetchDeployment,verifyDeployment}=await import(pathToFileURL(path.join(folder,'app/src/online/deployment.mjs')));
 const config=JSON.parse(readFileSync(path.join(root,'player-config.json'),'utf8'));let deployment;
 try{deployment=await fetchDeployment(config.directoryUrl,key);}catch(error){deployment=verifyDeployment(config.fallback,key);log('Using verified bundled server directory: '+error.message);}
 try{const result=await updater.install(deployment.updateFeed);if(result.version){pointer=updater.current();folder=select(pointer.current);process.env.CAVEGAME_APP_VERSION=pointer.current;}}catch(error){log('Update was not installed: '+error.message);}
 process.env.CAVEGAME_PLAYER_DEPLOYMENT=JSON.stringify(deployment);
 try{await import(pathToFileURL(path.join(folder,'app/scripts/start-online-client.mjs')));writeFileSync(pointerFile,JSON.stringify({...updater.current(),pending:false}));}
 catch(error){if(!updater.current().pending||!updater.current().previous)throw error;updater.rollback();log('Startup update rolled back: '+error.message);throw Error('The update could not start. The verified previous version has been restored; reopen Cavegame Reborn.');}
}catch(error){log(error.message);console.error(error.message);process.exitCode=1;}
