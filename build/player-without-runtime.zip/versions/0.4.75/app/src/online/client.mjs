import http from 'node:http';import {readFile} from 'node:fs/promises';import {existsSync,readFileSync,mkdirSync} from 'node:fs';import path from 'node:path';import {randomBytes,createHash} from 'node:crypto';
import {openIdentity,importIdentity} from './identity.mjs';import {ONLINE_PROTOCOL,ONLINE_VERSION} from './constants.mjs';import {writeJsonAtomic} from '../atomic-json.mjs';import {sharedClientAsset} from './client-assets.mjs';
import {packetSchemas} from './client-schemas.mjs';
import {alphaAgreementPolicy,alphaAcceptanceMessage,hasAlphaAcceptance} from './alpha-agreement.mjs';
import {inputObservation} from './input-observation.mjs';
async function boundedText(response,max=65536){let total=0;const chunks=[];for await(const chunk of response.body){total+=chunk.length;if(total>max)throw Error('Server response exceeds its size limit.');chunks.push(chunk);}return Buffer.concat(chunks).toString('utf8');}
const textType={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf'};
export function validateServerUrl(value){const u=new URL(value);if(u.username||u.password||u.search||u.hash||!['http:','https:'].includes(u.protocol)||u.pathname!=='/')throw Error('Use the HTTPS server address, without paths or credentials.');if(u.protocol==='http:'&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname))throw Error('Remote servers require HTTPS.');return u.origin;}
export async function signIn(base,key,nickname,{alphaAgreement,alphaReceipt}={}){
 const policy=alphaAgreementPolicy(alphaAgreement);
 if(!hasAlphaAcceptance(alphaReceipt,key.id,policy))throw Error('Read and accept the current Closed Alpha agreement before connecting.');
 const request=async(route,body)=>{const response=await fetch(base+route,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(12000),redirect:'error'});let data;try{data=JSON.parse(await boundedText(response));}catch{throw Error('The game server returned an unexpected page (HTTP '+response.status+'). Return to the launcher and press Play to refresh its verified address.');}if(!response.ok)throw Error(data.error??'Connection failed.');return data;};
 const info=await request('/v1/info');if(info.protocol!==ONLINE_PROTOCOL)throw Error('Server protocol incompatible. Update the client.');
 const remotePolicy=alphaAgreementPolicy(info.alphaAgreement);
 if(remotePolicy&&(!policy||remotePolicy.version!==policy.version||remotePolicy.sha256!==policy.sha256))throw Error('The server requires a different Closed Alpha agreement. Update the client and accept the current agreement.');
 if(policy&&!remotePolicy)throw Error('This Closed Alpha client requires an agreement-enabled server.');
 const c=await request('/v1/auth/challenge',{publicKey:key.publicKey}),message=JSON.parse(c.message);
 if(message.domain!=='cavegame-reborn.login.v1'||message.serverId!==info.serverId||message.audience!==base||message.protocol!==ONLINE_PROTOCOL||message.challengeId!==c.challengeId||message.expiresAt!==c.expiresAt||c.expiresAt<Date.now()-30000||c.expiresAt>Date.now()+90000)throw Error('Server login challenge invalid.');
 if(policy&&(message.alphaAgreement?.version!==policy.version||message.alphaAgreement?.sha256!==policy.sha256))throw Error('Server agreement challenge invalid.');
 const result=await request('/v1/auth/session',{challengeId:c.challengeId,signature:key.sign(c.message),nickname,protocol:ONLINE_PROTOCOL,clientVersion:ONLINE_VERSION,...(policy?{alphaAcceptance:{version:policy.version,sha256:policy.sha256,signature:key.sign(alphaAcceptanceMessage(c.message,policy))}}:{})});return {...result,serverFeatures:{inputTracing:info.features?.inputTracing===true,spawnZone:info.spawnZone??null}};
}
export async function signInForTransfer(base,key){
 const request=async(route,body)=>{const r=await fetch(base+route,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(12000),redirect:'error'}),data=JSON.parse(await boundedText(r));if(!r.ok)throw Error(data.error??'Transfer sign-in failed.');return data;};
 const info=await request('/v1/info');if(info.protocol!==ONLINE_PROTOCOL)throw Error('The official browser server is unavailable.');
 const c=await request('/v1/desktop-transfer/challenge',{publicKey:key.publicKey}),m=JSON.parse(c.message);
 if(m.domain!=='nolife.desktop-transfer.v1'||m.serverId!==info.serverId||m.origin!==base||m.protocol!==ONLINE_PROTOCOL||m.fingerprint!==createHash('sha256').update(Buffer.from(key.publicKey,'base64')).digest('hex')||m.challengeId!==c.challengeId||m.expiresAt!==c.expiresAt||m.expiresAt<Date.now()||m.expiresAt>Date.now()+90000)throw Error('Native transfer challenge verification failed.');
 return request('/v1/desktop-transfer/proof',{challengeId:c.challengeId,signature:key.sign(c.message)});
}
export function onlineAsset(filename,text,{endpoint,session,gameLease,launcherUrl='http://127.0.0.1:33910/'}){
 if(filename==='/index.html'){
  text=text.replace(/<script\b[^>]*src=["']\/world-menu\.js["'][^>]*><\/script>/g,'');
  text=text.replace('</head>','<link rel="stylesheet" href="/online-fidelity.css"><script defer src="/online-fidelity.js"></script></head>');
  const config=JSON.stringify({sessionToken:session.token,account:session.account,version:ONLINE_VERSION,protocol:ONLINE_PROTOCOL,launcherUrl,gameLease,spawnZone:session.serverFeatures?.spawnZone??null,schemas:packetSchemas}).replaceAll('<','\\u003c');
  return text.replace('<head>','<head><script>window.CavegameRemote='+JSON.stringify({endpoint})+';window.RebornOnline='+config+';</script><script src="/online-guard.js"></script><script src="/online-input.js"></script><script src="/online-spawn.js"></script><script src="/online-client.js"></script>');
 }
 if(filename==='/client.local.js')return sharedClientAsset(filename,text,endpoint).replace('data:window.CavegameLocalId','data:JSON.stringify({protocol:window.RebornOnline.protocol,token:window.RebornOnline.sessionToken})').replace('let s=e.data,r=new Uint8Array(s)[0];','let s=e.data;if(!window.RebornOnline.acceptPacket(s)){this.ws.close(4002);return;}let r=new Uint8Array(s)[0];window.RebornOnline.recordWire?.(r,s.byteLength);').replace('this.ws.send(a),delete o.__message','this.ws.send(a),window.RebornOnline.recordSent?.(e,this),delete o.__message').replace('window.CavegameView=this.localView','window.CavegameView=this.localView;window.RebornOnline.observeScene?.(this)').replace('this.room.ws.onopen=()=>{const t=h().currentUser;',`this.room.ws.onopen=async()=>{try{const r=await fetch('/launcher/refresh-session',{method:'POST'});const a=await r.json();if(!r.ok)throw Error(a.error);window.RebornOnline.sessionToken=a.token;}catch(e){this.serverError=e.message;this.room.leave();this.showDisconnect();return;}const t=h().currentUser;`);
 if(filename==='/local-content.js')return 'window.CavegameContent={version:1,items:{},blocks:[],initializeItem(){},preload(){}};';
 if(filename==='/local-content-runtime.js')return '';
 if(filename==='/local-adapter.js')return text.replace('setupLocalMenu();','window.RebornOnline.menuReady();');
 if(filename==='/player-view.js'&&!session.account.developer)return text.replace('async function loadMap(state,now){',"async function loadMap(state,now){$('pv-status').textContent='Survival: only revealed terrain is streamed';return;");
 return text;
}
export function createOnlineClient({directory,dataDirectory,port=33910,gamePort=port===0?0:33912,protectIdentity,defaultServer='http://127.0.0.1:33901',deployment,deploymentResolver,updater,onRestart,onQuit,onOpenBrowser,alphaAgreement,retireDesktop=false}={}){
 const publicRoot=path.join(directory,'public');mkdirSync(dataDirectory,{recursive:true});let identity=openIdentity(path.join(dataDirectory,'identity'),{protect:protectIdentity??process.platform==='win32'});
 const settingsFile=path.join(dataDirectory,'settings.json'),settings=existsSync(settingsFile)?JSON.parse(readFileSync(settingsFile,'utf8')):{server:defaultServer,nickname:'Player'};
 let policy=alphaAgreementPolicy(alphaAgreement);const agreementFile=path.join(dataDirectory,'alpha-agreement.json');let receipt=null;
 if(existsSync(agreementFile)){try{const saved=JSON.parse(readFileSync(agreementFile,'utf8'));if(saved.format===1)receipt=saved.receipt;}catch{/* A damaged receipt requires fresh, explicit acceptance. */}}
 const accepted=()=>hasAlphaAcceptance(receipt,identity.id,policy),agreementState=()=>({required:!!policy,policy,accepted:accepted(),acceptedAt:accepted()?receipt?.acceptedAt??null:null});
 const requireAgreement=()=>{if(!accepted())throw Error('Read and accept the current Closed Alpha agreement before connecting.');};
 const nonce=randomBytes(24).toString('base64url');let session=null,base=null,manualServer=null,lastActivity=Date.now(),agreementRevision=0,activeGameLease=null;
 let authenticationQueue=Promise.resolve();const diagnostics=[];
 const diagnostic=(stage,details={})=>{diagnostics.push({at:new Date().toISOString(),stage,...details});if(diagnostics.length>40)diagnostics.shift();try{writeJsonAtomic(path.join(dataDirectory,'connection-diagnostics.json'),{version:ONLINE_VERSION,identityId:identity.id,events:diagnostics});}catch{}};
 const serializedAuthentication=task=>{const next=authenticationQueue.then(task,task);authenticationQueue=next.catch(()=>{});return next;};
 const refreshDirectory=async(force=false)=>{if(deploymentResolver)deployment=await deploymentResolver.refresh({force});return deployment;};
 const refreshAgreement=async()=>{if(!retireDesktop)return;await refreshDirectory(true);const next=validateServerUrl(deployment?.server??defaultServer),response=await fetch(next+'/v1/info',{signal:AbortSignal.timeout(12000),redirect:'error'});if(!response.ok)throw Error('Cannot check the current Alpha agreement. Retry before transferring.');const info=JSON.parse(await boundedText(response)),current=alphaAgreementPolicy(info.alphaAgreement);if(!current||info.protocol!==ONLINE_PROTOCOL)throw Error('The official server must provide its current Alpha agreement.');if(policy?.sha256!==current.sha256||policy?.version!==current.version){policy=current;agreementRevision++;session=null;base=null;}return next;};
 const transferRequest=async(action,requestId)=>{if(!session||!base)throw Error('Start a new verified browser transfer first.');const response=await fetch(base+'/v1/desktop-browser-link',{method:action?'POST':'GET',headers:{Authorization:'Bearer '+session.token,'Content-Type':'application/json'},...(action?{body:JSON.stringify({action,requestId})}:{}),signal:AbortSignal.timeout(12000),redirect:'error'}),result=JSON.parse(await boundedText(response));if(!response.ok)throw Error(result.error??'Browser transfer failed.');return result;};
 const refreshGameplayDirectory=async()=>{try{return await refreshDirectory();}catch(e){if(!manualServer)throw e;return deployment;}};
 const endRemoteSession=async(serverBase,previous)=>{if(!previous||!serverBase)return;try{await fetch(serverBase+'/v1/session/end',{method:'POST',headers:{Authorization:'Bearer '+previous.token,'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(3000),redirect:'error'});}catch{}};
 const authenticate=async(next,nickname)=>{const revision=agreementRevision,key=identity,result=await signIn(next,key,nickname,{alphaAgreement:policy,alphaReceipt:receipt});if(revision!==agreementRevision||key!==identity||!accepted()){await endRemoteSession(next,result);throw Error('Launcher access changed. Review the agreement and connect again.');}return result;};
 let server,gameServer;
 const handler=isGame=>async(req,res)=>{
  const reply=(status,value,type='application/json; charset=utf-8')=>{res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; img-src 'self' data: blob:; worker-src 'self' blob:; frame-src 'none'; frame-ancestors 'none'"});res.end(Buffer.isBuffer(value)||typeof value==='string'?value:JSON.stringify(value));};
  try{
   const bound=(isGame?gameServer:server).address()?.port;if(!['127.0.0.1:'+bound,'localhost:'+bound].includes(req.headers.host))return reply(403,{error:'Local host required.'});
   if(req.method!=='GET'&&req.headers.origin!==`http://${req.headers.host}`&&req.headers['x-reborn-launcher']!==nonce)return reply(403,{error:'Local launcher origin required.'});
   const url=new URL(req.url,'http://localhost');let filename=decodeURIComponent(url.pathname);lastActivity=Date.now();
   if(retireDesktop){
    const allowed=['/health','/','/launcher','/online-retirement.js','/launcher/agreement','/launcher/transfer/start','/launcher/transfer/pending','/launcher/transfer/confirm','/launcher/heartbeat','/launcher/recovery/export','/launcher/recovery/import','/launcher/quit','/launcher/restart','/launcher/update/check','/launcher/update/install'];
    if(isGame||!allowed.includes(filename)&&!['.css','.png','.svg','.ico','.woff','.woff2','.ttf'].includes(path.extname(filename)))return reply(410,{error:'The downloaded game is discontinued. Open the launcher to transfer your existing account to the browser game.'});
   }
   const requireCurrentGame=()=>{if(isGame&&activeGameLease&&req.headers['x-reborn-game']!==activeGameLease){const error=Error('A newer game window is active. Use the launcher to open the current game.');error.status=409;error.code='STALE_GAME_WINDOW';throw error;}};
   const launcherUrl='http://127.0.0.1:'+server.address().port+'/',gameUrl='http://127.0.0.1:'+gameServer.address().port;
   if(isGame&&filename.startsWith('/launcher/')&&!['/launcher/heartbeat','/launcher/refresh-session','/launcher/input-report'].includes(filename))return reply(403,{error:'Identity recovery and updates require the separate launcher.'});
   if(isGame&&activeGameLease&&(filename.startsWith('/local/')||filename.startsWith('/v1/')||filename==='/launcher/refresh-session'||filename==='/launcher/input-report')){requireAgreement();if(req.headers['x-reborn-game']!==activeGameLease)return reply(409,{error:'A newer game window is active. Use the launcher to open the current game.',code:'STALE_GAME_WINDOW'});}
   if(isGame&&['/','/launcher'].includes(filename)||!isGame&&['/play','/index.html'].includes(filename)){res.writeHead(303,{Location:isGame?launcherUrl:gameUrl+'/play'});return res.end();}
   const readBody=async()=>{let text='';for await(const b of req){text+=b.toString();if(Buffer.byteLength(text)>65536)throw Error('Request too large.');}return JSON.parse(text||'{}');};
   if(filename==='/health')return reply(200,{ok:true,clientOnly:true,version:ONLINE_VERSION,identityId:identity.id,pid:process.pid});
   if(filename==='/launcher/agreement'&&req.method==='GET'){await refreshAgreement();return reply(200,agreementState());}
   if(retireDesktop&&filename==='/launcher/transfer/start'&&req.method==='POST')return await serializedAuthentication(async()=>{const next=await refreshAgreement();session=await signInForTransfer(next,identity);base=next;const result=session.newPlayer?{url:session.url,newPlayer:true}:await transferRequest('transfer');if(new URL(result.url).origin!==next||new URL(result.url).pathname!=='/web/')throw Error('Browser destination verification failed.');onOpenBrowser?.(result.url);return reply(200,{...result,opened:!!onOpenBrowser});});
   if(retireDesktop&&filename==='/launcher/transfer/pending'&&req.method==='POST')return reply(200,await transferRequest());
   if(retireDesktop&&filename==='/launcher/transfer/confirm'&&req.method==='POST'){const input=await readBody(),pending=await transferRequest(),match=pending.requests.find(p=>p.requestId===input.requestId&&p.fingerprint===input.fingerprint);if(!match)throw Error('Transfer browser changed or expired. Start again and compare its fingerprint.');return reply(200,await transferRequest('confirm',match.requestId));}
   if(filename==='/launcher/agreement'&&req.method==='POST'){
    const body=await readBody();if(!policy)throw Error('Closed Alpha agreement is not enabled.');
    if(body.version!==policy.version||body.sha256!==policy.sha256||!['accept','decline'].includes(body.decision))throw Error('Choose I AGREE or DECLINE for the current Closed Alpha agreement.');
    const next={accepted:body.decision==='accept',identityId:identity.id,version:policy.version,sha256:policy.sha256,...(body.decision==='accept'?{acceptedAt:Date.now()}:{declinedAt:Date.now()})};
    writeJsonAtomic(agreementFile,{format:1,receipt:next});receipt=next;agreementRevision++;
    if(!next.accepted){const previous=session,previousBase=base;session=null;base=null;await endRemoteSession(previousBase,previous);}
    return reply(200,agreementState());
   }
   if(filename==='/launcher/connect'&&req.method==='POST'){
    requireAgreement();const body=await readBody(),manual=body.manualOverride===true;
    if(manual&&body.confirmManual!==true)throw Error('Confirm the temporary manual server choice.');
    const override=manual?validateServerUrl(body.manualServer):null;
    if(manual){try{await refreshDirectory(true);}catch{/* Explicit gameplay choice does not replace trusted update configuration. */}}else await refreshDirectory(true);
    let next=override??validateServerUrl(deployment?.server??body.server),result;
    return await serializedAuthentication(async()=>{
    requireAgreement();
    try{result=await authenticate(next,body.nickname);}catch(error){
     if(manual)throw error;
     // A host can move between directory fetch and login. Retry only after a
     // newly signed directory actually changes the destination.
     await refreshDirectory(true);const moved=deployment?.server;if(!moved||moved===next)throw error;next=validateServerUrl(moved);result=await authenticate(next,body.nickname);
    }
    requireAgreement();session=result;base=next;manualServer=override;settings.server=next;settings.nickname=session.account.nickname;writeJsonAtomic(settingsFile,settings);diagnostic('login',{accountId:session.account.id,server:base,manualOverride:!!manualServer});return reply(200,{ok:true,url:gameUrl+'/play',account:session.account});});
   }
   if(filename==='/launcher/refresh-session'&&req.method==='POST'){requireAgreement();if(!base)throw Error('Connect through the launcher first.');await refreshGameplayDirectory();if(!manualServer&&deployment&&base!==deployment.server)return reply(409,{error:'The Alpha host restarted. Return to the launcher and press Play to reconnect automatically.',reconnectRequired:true});return await serializedAuthentication(async()=>{requireAgreement();requireCurrentGame();if(!base)throw Error('Connect through the launcher first.');
    // Game handshakes reuse the already authenticated session. Logging in again
    // revokes the previous token on the authoritative server, including an
    // already open game socket. Concurrent handshakes must not rotate each other.
    let valid=!!session&&session.expiresAt>Date.now()+30000;
    if(valid){const checked=await fetch(base+'/v1/self',{headers:{Authorization:'Bearer '+session.token},signal:AbortSignal.timeout(12000),redirect:'error'});const state=JSON.parse(await boundedText(checked));if(!checked.ok){if(checked.status===403&&/^Session expired\./.test(state.error??''))valid=false;else throw Error(state.error??'Session validation failed.');}else if(state.id!==identity.id)throw Error('Authenticated account does not match this device.');}
    requireCurrentGame();if(!valid){const result=await authenticate(base,settings.nickname);requireAgreement();requireCurrentGame();session=result;diagnostic('session-refreshed',{accountId:session.account.id});}
    requireCurrentGame();
    return reply(200,{token:session.token,account:session.account});});}
   if(filename==='/launcher/input-report'&&req.method==='POST'){
    requireAgreement();const body=await readBody();if(JSON.stringify(body).length>6000)throw Error('Diagnostic report too large.');
    const observation=inputObservation(body,identity.id);diagnostic('browser-input',{accountId:session?.account.id??null,report:observation});
    if(session?.serverFeatures?.inputTracing&&base){try{const remote=await fetch(base+'/v1/input-observations',{method:'POST',headers:{Authorization:'Bearer '+session.token,'Content-Type':'application/json'},body:JSON.stringify(observation),signal:AbortSignal.timeout(8000),redirect:'error'});if(!remote.ok)diagnostic('report-forward-error',{status:remote.status});}catch(error){diagnostic('report-forward-error',{error:error.message,cause:error.cause?.code??null});}}
    return reply(200,{ok:true});
   }
   if(filename==='/launcher/recovery/export'&&req.method==='POST'){const body=await readBody();return reply(200,identity.exportBackup(body.passphrase));}
   if(filename==='/launcher/recovery/import'&&req.method==='POST'){
    const body=await readBody();if(body.confirm!==true)throw Error('Confirm replacing this device identity.');
    if(session&&base){try{const r=await fetch(base+'/v1/self',{headers:{Authorization:'Bearer '+session.token},signal:AbortSignal.timeout(3000)});const state=await r.json();if(state.joined)throw Error('Leave the game before replacing your identity.');}catch(e){if(e.message.includes('Leave the game'))throw e;}}
    const previous=session,previousBase=base;identity=importIdentity(path.join(dataDirectory,'identity'),body.backup,body.passphrase,{protect:protectIdentity??process.platform==='win32'});agreementRevision++;session=null;base=null;await endRemoteSession(previousBase,previous);return reply(200,{ok:true,identityId:identity.id});
   }
   if(filename==='/launcher/heartbeat'){await refreshGameplayDirectory();return reply(200,{ok:true,server:manualServer??deployment?.server??settings.server,manualOverride:!!manualServer,reconnectRequired:!!(!manualServer&&base&&deployment&&base!==deployment.server),directoryWarning:deploymentResolver?.error??null});}
   if(filename==='/launcher/update/check'){if(!updater)throw Error('Updates are available in the packaged client.');await refreshDirectory(true);return reply(200,await updater.check(deployment?.updateFeed??settings.updateFeed??(settings.server+'/releases/stable.json')));}
   if(filename==='/launcher/update/install'&&req.method==='POST'){if(!updater)throw Error('Packaged client required.');await refreshDirectory(true);return reply(200,await updater.install(deployment?.updateFeed??settings.updateFeed??(settings.server+'/releases/stable.json')));}
   if(filename==='/launcher/update/rollback'&&req.method==='POST'){if(!updater)throw Error('Packaged client required.');return reply(200,updater.rollback());}
   if(filename==='/launcher/restart'&&req.method==='POST'){if(!onRestart)throw Error('Restart through the desktop launcher.');reply(200,{ok:true,pid:process.pid});setTimeout(onRestart,200).unref();return;}
   if(filename==='/launcher/quit'&&req.method==='POST'){if(!onQuit)throw Error('Close the desktop client.');reply(200,{ok:true});setTimeout(onQuit,200).unref();return;}
   if(filename.startsWith('/v1/')||filename.startsWith('/local/')){
    requireAgreement();
    if(!session||!base)throw Error('Connect through the launcher first.');
    const route=filename==='/local/diagnostics'?'/v1/diagnostics':filename;
    const body=req.method==='POST'?JSON.stringify(await readBody()):undefined;
    const response=await fetch(base+route+url.search,{method:req.method,headers:{Authorization:'Bearer '+session.token,'Content-Type':'application/json'},body,signal:AbortSignal.timeout(30000),redirect:'error'}),text=await boundedText(response,16*1024*1024);
    if(!response.ok){let error;try{error=JSON.parse(text).error;}catch{error='Non-JSON remote error';}diagnostic('remote-api-error',{route,status:response.status,error:String(error??'').slice(0,400),accountId:session.account.id,requestedId:url.searchParams.get('id')?.slice(0,80)??null});}
    return reply(response.status,text);
   }
   if(filename==='/cavegame-io-servers')return reply(200,{states:[{title:'REBORN ONLINE',ip:base?.replace('http','ws')+'/ws',playerCount:'?',best:true}]});
   if(filename==='/event-info')return reply(200,'false','text/plain');
   if(filename==='/'||filename==='/launcher'){
    await refreshDirectory();
    if(retireDesktop)await refreshAgreement();
    let page=await readFile(path.join(publicRoot,retireDesktop?'online-retirement.html':'online-launcher.html'),'utf8');const config=JSON.stringify({nonce,settings:{...settings,...(deployment?{server:deployment.server,updateFeed:deployment.updateFeed}:{})},managed:!!deployment,version:ONLINE_VERSION,identityId:identity.id,alphaAgreement:agreementState()}).replaceAll('<','\\u003c');page=page.replace('/*LAUNCHER_CONFIG*/','window.RebornLauncher='+config+';');return reply(200,page,'text/html; charset=utf-8');
   }
   if(filename==='/play'){requireAgreement();if(!session||session.expiresAt<=Date.now())throw Error('Sign in through the launcher again.');filename='/index.html';}
   if(filename==='/index.html')requireAgreement();
   if(filename==='/index.html'&&!session)throw Error('Use the launcher first.');
   if(isGame&&filename==='/index.html'){activeGameLease=randomBytes(24).toString('base64url');diagnostic('game-window-opened',{accountId:session.account.id});}
   if(!isGame&&!['/online-launcher.js','/online-retirement.js'].includes(filename)&&!['.css','.png','.svg','.ico','.woff','.woff2','.ttf'].includes(path.extname(filename)))return reply(403,{error:'Game assets use the separate game origin.'});
   const resolved=path.resolve(publicRoot,'.'+filename);if(!resolved.startsWith(publicRoot+path.sep))return reply(403,{error:'Invalid asset path.'});
    let data=await readFile(resolved);if(session&&['/index.html','/client.local.js','/local-adapter.js','/player-view.js','/local-content.js','/local-content-runtime.js'].includes(filename))data=Buffer.from(onlineAsset(filename,data.toString(),{endpoint:base.replace('http','ws')+'/ws',session,gameLease:activeGameLease,launcherUrl}));
   return reply(200,data,textType[path.extname(filename)]??'application/octet-stream');
  }catch(e){const status=e.status??(e.code==='ENOENT'?404:/agreement before connecting/i.test(e.message)?403:400);if(req.url.startsWith('/local/')||req.url.startsWith('/launcher/refresh-session'))diagnostic('local-request-error',{route:req.url.split('?')[0],status,error:e.message,cause:e.cause?.code??null,accountId:session?.account.id??null});reply(status,{error:e.message,...(e.code==='STALE_GAME_WINDOW'?{code:e.code}:{})});}
 };
 server=http.createServer(handler(false));gameServer=http.createServer(handler(true));
 return {server,gameServer,get identity(){return identity;},nonce,settings,start:async()=>{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});try{await new Promise((resolve,reject)=>{gameServer.once('error',reject);gameServer.listen(gamePort,'127.0.0.1',resolve);});}catch(e){await new Promise(r=>server.close(r));throw e;}},stop:()=>Promise.all([new Promise(r=>server.close(r)),new Promise(r=>gameServer.close(r))]),lastActivity:()=>lastActivity};
}
