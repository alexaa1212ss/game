// Closed Alpha policy only. Offline and public-release callers opt out by omitting it.
import {createHash} from 'node:crypto';

export function alphaAgreementPolicy(value){
 if(value===undefined||value===null||value===false)return null;
 if(value===true)return CLOSED_ALPHA_AGREEMENT;
 if(!value||typeof value!=='object'||typeof value.version!=='string'||!/^[A-Za-z0-9._-]{1,64}$/.test(value.version)||typeof value.title!=='string'||value.title.length<1||value.title.length>160||!Array.isArray(value.paragraphs)||value.paragraphs.length<1||value.paragraphs.length>10||value.paragraphs.some(p=>typeof p!=='string'||!p.length||p.length>4000))throw Error('Invalid Closed Alpha agreement policy.');
 const paragraphs=Object.freeze([...value.paragraphs]),sha256=createHash('sha256').update(JSON.stringify({title:value.title,paragraphs})).digest('hex');
 if(value.sha256!==undefined&&value.sha256!==sha256)throw Error('Closed Alpha agreement content digest mismatch.');
 return Object.freeze({version:value.version,title:value.title,paragraphs,sha256});
}

export const CLOSED_ALPHA_AGREEMENT=alphaAgreementPolicy({
 version:'nolife-alpha-4',
 title:'NOLIFE.IO — ALPHA TESTING AGREEMENT',
 paragraphs:[
  'Welcome to the NoLife.io Alpha!',
  'This is an early version of the game, so expect bugs, unfinished features, and occasional resets. Your feedback helps improve the game before release.',
  'By playing, you agree to:\nNo cheating or exploiting. Do not use scripts, bots, hacks, modified clients, or other unauthorized tools to gain an unfair advantage.\nNo abusing bugs. If you discover an exploit, report it instead of using it to gain an advantage or disrupt other players.\nNo intentionally crashing or attacking servers. Do not attempt to lag, overload, or disrupt the game or its services.\nRespect other players. No harassment, threats, or deliberately ruining the testing experience.',
  'Sharing is allowed!',
  'You are welcome to share the Alpha download link, invite friends, record gameplay, stream, and post screenshots or videos.',
  'Violations may result in temporary or permanent removal from the Alpha, depending on severity.',
  'By continuing, you agree to follow these rules.',
  'Thank you for helping test NoLife.io!'
 ]
});

export function hasAlphaAcceptance(receipt,identityId,policy){
 return !policy||receipt?.accepted===true&&receipt.identityId===identityId&&receipt.version===policy.version&&receipt.sha256===policy.sha256&&Number.isSafeInteger(receipt.acceptedAt)&&receipt.acceptedAt>0;
}

// Separate from the login signature: an older client signing a challenge with
// unknown fields must never be mistaken for an explicit agreement acceptance.
export function alphaAcceptanceMessage(challengeMessage,policy){
 return JSON.stringify({domain:'cavegame-reborn.alpha-agreement.v1',challenge:challengeMessage,version:policy.version,sha256:policy.sha256,decision:'I AGREE'});
}
