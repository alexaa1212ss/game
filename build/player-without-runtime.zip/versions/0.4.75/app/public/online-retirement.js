(() => {
 const $=id=>document.getElementById(id),config=window.RebornLauncher;let pending=null,timer=null,busy=false,waiting=false,done=false;
 const request=async(route,body)=>{const r=await fetch(route,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','x-reborn-launcher':config.nonce},body:body?JSON.stringify(body):undefined,cache:'no-store'}),data=await r.json();if(!r.ok)throw Error(data.error);return data;};
 const reset=text=>{clearInterval(timer);pending=null;waiting=false;$('confirmation').hidden=true;$('transfer').disabled=false;$('transfer').textContent='Move to browser';$('feedback').textContent=text;};
 $('transfer').onclick=async()=>{
  if(busy||done||waiting&&!pending)return;busy=true;$('transfer').disabled=true;
  try{
   if(pending){await request('/launcher/transfer/confirm',{requestId:pending.requestId,fingerprint:pending.fingerprint});clearInterval(timer);pending=null;waiting=false;done=true;$('confirmation').hidden=true;$('transfer').textContent='Browser linked';$('feedback').textContent='Continue account setup in your browser, then play with your original progress.';return;}
   const result=await request('/launcher/transfer/start',{}),link=new URL(result.url);if(link.origin!==new URL(config.settings.server).origin||link.pathname!=='/web/')throw Error('Browser destination verification failed.');
   $('browser-link').href=link.href;if(!result.opened)window.open(link.href,'_blank','noopener,noreferrer');
   if(result.newPlayer){$('feedback').textContent='No online save is attached to this downloaded identity. The official browser game is open for Sign Up or Sign In. Existing identities have not been changed.';return;}
   waiting=true;$('transfer').textContent='Waiting for your browser…';$('feedback').textContent='Accept the agreement in your browser. Then compare fingerprints here to finish securely.';
   timer=setInterval(async()=>{try{if(Date.now()>=result.expiresAt){reset('Transfer expired. Click to open a fresh link. Your progress is safe.');return;}const state=await request('/launcher/transfer/pending',{});pending=state.requests[0]??null;$('confirmation').hidden=!pending;if(pending){$('fingerprint').textContent=pending.fingerprint;$('browser-label').textContent=pending.label;$('transfer').textContent='Fingerprints match — confirm my browser';$('transfer').disabled=false;}}catch(e){reset(e.message);}},2000);
  }catch(e){reset(e.message);}finally{busy=false;if(!waiting&&!done)$('transfer').disabled=false;}
 };
 $('version').textContent='Final desktop migration client · '+config.version;setInterval(()=>request('/launcher/heartbeat').catch(()=>{}),10000);
})();
