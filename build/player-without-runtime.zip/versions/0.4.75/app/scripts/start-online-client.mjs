import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';import {existsSync,readFileSync} from 'node:fs';import {spawn} from 'node:child_process';
import {createOnlineClient} from '../src/online/client.mjs';import {ReleaseUpdater} from '../src/online/update.mjs';
import {CLOSED_ALPHA_AGREEMENT} from '../src/online/alpha-agreement.mjs';
import {createDeploymentResolver} from '../src/online/deployment.mjs';
import {refreshWindowsIcon} from '../src/online/windows-icon.mjs';
import {ONLINE_VERSION} from '../src/online/constants.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),dataDirectory=process.env.CAVEGAME_CLIENT_DATA??path.join(process.env.LOCALAPPDATA??os.homedir(),'CavegameReborn');
const port=Number(process.env.CAVEGAME_CLIENT_PORT??33930),gamePort=Number(process.env.CAVEGAME_GAME_PORT??33932),url='http://127.0.0.1:'+port+'/';
refreshWindowsIcon(process.env.CAVEGAME_INSTALL_ROOT,path.join(root,'public/asset/reborn-app.ico'));
const open=()=>{const edge=path.join(process.env['ProgramFiles(x86)']??'C:\\Program Files (x86)','Microsoft/Edge/Application/msedge.exe');if(existsSync(edge))spawn(edge,['--app='+url],{stdio:'ignore',detached:true,windowsHide:false}).unref();else spawn('explorer.exe',[url],{stdio:'ignore',detached:true,windowsHide:true}).unref();};
let existing;try{existing=await(await fetch(url+'health',{signal:AbortSignal.timeout(700)})).json();}catch{}
if(existing?.clientOnly){
 if(existing.version!==ONLINE_VERSION){
  const response=await fetch(url+'launcher/restart',{method:'POST',headers:{Origin:url.slice(0,-1)},signal:AbortSignal.timeout(3000)});if(!response.ok)throw Error('Close the previous launcher before activating the verified update.');
  // The existing process saves its state and starts the verified bootstrap.
  // Do not leave the user in the old process after advancing installed.json.
  for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,500));try{const h=await(await fetch(url+'health',{signal:AbortSignal.timeout(700)})).json();if(h.clientOnly&&h.version===ONLINE_VERSION)process.exit(0);}catch{}}
  throw Error('The updated launcher is taking longer to restart. Reopen Cavegame Reborn.');
 }
 if(!process.argv.includes('--no-browser'))open();process.exit(0);
}
const deployment=JSON.parse(process.env.CAVEGAME_PLAYER_DEPLOYMENT),updater=new ReleaseUpdater({directory:process.env.CAVEGAME_INSTALL_ROOT,product:'RebornPlayer'});
const config=JSON.parse(readFileSync(path.join(process.env.CAVEGAME_INSTALL_ROOT,'player-config.json'),'utf8'));
const deploymentResolver=createDeploymentResolver({url:config.directoryUrl,key:updater.key,initial:deployment,cacheFile:path.join(dataDirectory,'verified-server-directory.json')});
let idle;const quit=async()=>{clearInterval(idle);await client.stop();process.exit(0);};
const restart=async()=>{await client.stop();clearInterval(idle);const install=process.env.CAVEGAME_INSTALL_ROOT,version=updater.current().current;spawn(path.join(install,'versions',version,'runtime/node.exe'),[path.join(install,'bootstrap.mjs'),install,'client'],{stdio:'ignore',detached:true,windowsHide:true}).unref();process.exit(0);};
const client=createOnlineClient({directory:root,dataDirectory,port,gamePort,defaultServer:deployment.server,deployment,deploymentResolver,updater,onQuit:quit,onRestart:restart,onOpenBrowser:target=>spawn('rundll32.exe',['url.dll,FileProtocolHandler',target],{stdio:'ignore',detached:true,windowsHide:true}).unref(),alphaAgreement:CLOSED_ALPHA_AGREEMENT,retireDesktop:true});await client.start();
if(!process.argv.includes('--no-browser'))open();idle=setInterval(()=>{if(Date.now()-client.lastActivity()>90000)quit();},15000);
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,quit);
