import {mkdirSync,writeFileSync,renameSync,unlinkSync} from 'node:fs';
import {dirname} from 'node:path';
// Preserve the previous completed save and reclaim partial temporary output
// after ENOSPC/locked-target failures. Never remove the completed save itself.
export function writeJsonAtomic(filename,value){
  const temporary=filename+'.tmp';mkdirSync(dirname(filename),{recursive:true});
  try{writeFileSync(temporary,JSON.stringify(value,null,2));renameSync(temporary,filename);}
  catch(error){try{unlinkSync(temporary);}catch{}if(error.code==='ENOSPC')error.message='Not enough free disk space to save. The previous completed save is intact; free disk space and retry.';throw error;}
}
