import {readFileSync,writeFileSync,mkdirSync,existsSync,lstatSync} from 'node:fs';import path from 'node:path';import {deflateRawSync,inflateRawSync} from 'node:zlib';
const table=Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
export function crc32(bytes){let n=0xffffffff;for(const byte of bytes)n=table[(n^byte)&255]^(n>>>8);return (n^0xffffffff)>>>0;}
export function safeZipName(name){
 if(typeof name!=='string'||!name||name.length>220||name.startsWith('/')||name.includes('\\')||name.includes(':')||name.includes('\0'))throw Error('Unsafe archive path.');
 const parts=name.split('/');if(parts.some(p=>!p||p==='.'||p==='..'||/[. ]$/.test(p)||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(p)))throw Error('Unsafe archive path.');return name;
}
export function writeZip(files,filename){
 const locals=[],central=[];let offset=0;
 for(const file of files){
  const name=Buffer.from(safeZipName(file.name)),raw=file.bytes??readFileSync(file.path),deflated=deflateRawSync(raw,{level:6}),compressed=deflated.length<raw.length?deflated:raw,method=compressed===raw?0:8,crc=crc32(raw);
  if(raw.length>150*1024*1024)throw Error('Archive file too large.');
  const head=Buffer.alloc(30);head.writeUInt32LE(0x04034b50,0);head.writeUInt16LE(20,4);head.writeUInt16LE(0x800,6);head.writeUInt16LE(method,8);head.writeUInt32LE(crc,14);head.writeUInt32LE(compressed.length,18);head.writeUInt32LE(raw.length,22);head.writeUInt16LE(name.length,26);
  const entry=Buffer.alloc(46);entry.writeUInt32LE(0x02014b50,0);entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(0x800,8);entry.writeUInt16LE(method,10);entry.writeUInt32LE(crc,16);entry.writeUInt32LE(compressed.length,20);entry.writeUInt32LE(raw.length,24);entry.writeUInt16LE(name.length,28);entry.writeUInt32LE(offset,42);
  locals.push(head,name,compressed);central.push(entry,name);offset+=head.length+name.length+compressed.length;
 }
 const body=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(files.length,8);end.writeUInt16LE(files.length,10);end.writeUInt32LE(body.length,12);end.writeUInt32LE(offset,16);mkdirSync(path.dirname(filename),{recursive:true});writeFileSync(filename,Buffer.concat([...locals,body,end]));
}
export function extractZip(input,directory,{maxBytes=500*1024*1024,maxFiles=10000}={}){
 const bytes=Buffer.isBuffer(input)?input:readFileSync(input);if(bytes.length>maxBytes)throw Error('Archive exceeds download limit.');let end=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(bytes.readUInt32LE(i)===0x06054b50&&i+22+bytes.readUInt16LE(i+20)===bytes.length){end=i;break;}
 if(end<0)throw Error('Archive footer missing.');const count=bytes.readUInt16LE(end+10),centralSize=bytes.readUInt32LE(end+12),centralOffset=bytes.readUInt32LE(end+16);
 if(bytes.readUInt16LE(end+4)||bytes.readUInt16LE(end+6)||count!==bytes.readUInt16LE(end+8)||count>maxFiles||centralOffset+centralSize!==end)throw Error('Unsupported or oversized archive.');
 const entries=[],names=new Set();let offset=centralOffset,total=0;
 for(let i=0;i<count;i++){
  if(offset+46>end||bytes.readUInt32LE(offset)!==0x02014b50)throw Error('Invalid archive directory.');
  const flags=bytes.readUInt16LE(offset+8),method=bytes.readUInt16LE(offset+10),crc=bytes.readUInt32LE(offset+16),size=bytes.readUInt32LE(offset+20),rawSize=bytes.readUInt32LE(offset+24),n=bytes.readUInt16LE(offset+28),extra=bytes.readUInt16LE(offset+30),comment=bytes.readUInt16LE(offset+32),attributes=bytes.readUInt32LE(offset+38),local=bytes.readUInt32LE(offset+42);
  if(offset+46+n+extra+comment>end||flags&1||![0,8].includes(method)||(attributes>>>16&0xf000)===0xa000)throw Error('Unsupported archive entry.');
  const nameBytes=bytes.subarray(offset+46,offset+46+n),name=safeZipName(nameBytes.toString('utf8'));if(!Buffer.from(name).equals(nameBytes)||names.has(name.toLowerCase()))throw Error('Duplicate or invalid archive filename.');names.add(name.toLowerCase());
  total+=rawSize;if(rawSize>150*1024*1024||total>maxBytes)throw Error('Unpacked archive too large.');
  if(local+30>centralOffset||bytes.readUInt32LE(local)!==0x04034b50)throw Error('Invalid archive entry header.');const start=local+30+bytes.readUInt16LE(local+26)+bytes.readUInt16LE(local+28);if(start+size>centralOffset)throw Error('Invalid compressed data bounds.');entries.push({name,method,crc,rawSize,data:bytes.subarray(start,start+size)});offset+=46+n+extra+comment;
 }
 if(offset!==end)throw Error('Invalid archive directory size.');const base=path.resolve(directory);mkdirSync(base,{recursive:true});
 for(const entry of entries){
  const target=path.resolve(base,...entry.name.split('/'));if(!target.startsWith(base+path.sep))throw Error('Archive escapes staging directory.');
  let cursor=base;for(const part of entry.name.split('/').slice(0,-1)){cursor=path.join(cursor,part);if(existsSync(cursor)&&lstatSync(cursor).isSymbolicLink())throw Error('Archive staging symlink rejected.');}
  if(existsSync(target))throw Error('Archive cannot overwrite a staged file.');const data=entry.method===8?inflateRawSync(entry.data,{maxOutputLength:entry.rawSize||1}):entry.data;if(data.length!==entry.rawSize||crc32(data)!==entry.crc)throw Error('Archive data integrity failure.');mkdirSync(path.dirname(target),{recursive:true});writeFileSync(target,data,{flag:'wx'});
 }return {files:entries.length,bytes:total};
}
