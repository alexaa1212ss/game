import {generateKeyPairSync,createPrivateKey,createPublicKey,createHash,sign,randomBytes,scryptSync,createCipheriv,createDecipheriv} from 'node:crypto';
import {existsSync,mkdirSync,readFileSync,copyFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {writeJsonAtomic} from '../atomic-json.mjs';
export const accountId=publicKey=>'r_'+createHash('sha256').update(Buffer.from(publicKey,'base64')).digest('hex').slice(0,48);
function dpapi(value,operation){
 const command="Add-Type -AssemblyName System.Security; $v=[Convert]::FromBase64String([Console]::In.ReadToEnd()); $r=[Security.Cryptography.ProtectedData]::"+operation+"($v,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Out.Write([Convert]::ToBase64String($r))";
 const result=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',command],{input:value,encoding:'utf8',windowsHide:true,timeout:15000});
 if(result.status!==0)throw Error('Windows account protection for the login key failed. No plaintext key was saved.');return result.stdout.trim();
}
export function openIdentity(directory,{protect=process.platform==='win32'}={}){
 mkdirSync(directory,{recursive:true,mode:0o700});const filename=path.join(directory,'identity.json');let data;
 if(existsSync(filename))data=JSON.parse(readFileSync(filename,'utf8'));
 else{
  const pair=generateKeyPairSync('ed25519'),publicKey=pair.publicKey.export({type:'spki',format:'der'}).toString('base64'),privateKey=pair.privateKey.export({type:'pkcs8',format:'der'}).toString('base64');
  data={version:1,publicKey,protection:protect?'windows-dpapi':'file-permissions',privateKey:protect?dpapi(privateKey,'Protect'):privateKey};writeJsonAtomic(filename,data);
 }
 if(data.version!==1)throw Error('Unsupported local login key.');
 let unlocked=data.privateKey;
 if(data.protection==='windows-dpapi'){
  unlocked=null;for(const envelope of [data.privateKey,...(Array.isArray(data.alternateWindowsProtection)?data.alternateWindowsProtection.slice(0,3):[])]){try{unlocked=dpapi(envelope,'Unprotect');break;}catch{}}
  if(!unlocked)throw Error('This Windows account cannot unlock the local identity. Restore an encrypted recovery key or use the authorized local identity repair.');
 }
 const privateKey=createPrivateKey({key:Buffer.from(unlocked,'base64'),format:'der',type:'pkcs8'});
 const publicKey=createPublicKey(privateKey).export({type:'spki',format:'der'}).toString('base64');if(publicKey!==data.publicKey)throw Error('Login key is corrupt.');
 return {id:accountId(publicKey),publicKey,sign:message=>sign(null,Buffer.from(message),privateKey).toString('base64'),filename,exportBackup:passphrase=>{
  if(typeof passphrase!=='string'||passphrase.length<12||passphrase.length>1024)throw Error('Recovery passphrase must contain 12–1024 characters.');
  const salt=randomBytes(16),iv=randomBytes(12),key=scryptSync(passphrase,salt,32),cipher=createCipheriv('aes-256-gcm',key,iv),raw=privateKey.export({type:'pkcs8',format:'der'}),encrypted=Buffer.concat([cipher.update(raw),cipher.final()]);
  return {format:'reborn-recovery-v1',publicKey,salt:salt.toString('base64'),iv:iv.toString('base64'),tag:cipher.getAuthTag().toString('base64'),encrypted:encrypted.toString('base64')};
 }};
}
export function importIdentity(directory,backup,passphrase,{protect=process.platform==='win32'}={}){
 if(backup?.format!=='reborn-recovery-v1'||typeof passphrase!=='string'||passphrase.length<12||passphrase.length>1024||JSON.stringify(backup).length>4096)throw Error('Invalid recovery key or passphrase.');
 let raw,publicKey;
 try{const salt=Buffer.from(backup.salt,'base64'),iv=Buffer.from(backup.iv,'base64'),tag=Buffer.from(backup.tag,'base64');if(salt.length!==16||iv.length!==12||tag.length!==16)throw Error();const cipher=createDecipheriv('aes-256-gcm',scryptSync(passphrase,salt,32),iv);cipher.setAuthTag(tag);raw=Buffer.concat([cipher.update(Buffer.from(backup.encrypted,'base64')),cipher.final()]);const key=createPrivateKey({key:raw,format:'der',type:'pkcs8'});if(key.asymmetricKeyType!=='ed25519')throw Error();publicKey=createPublicKey(key).export({type:'spki',format:'der'}).toString('base64');if(publicKey!==backup.publicKey)throw Error();}catch{throw Error('Invalid recovery key or passphrase.');}
 mkdirSync(directory,{recursive:true,mode:0o700});const file=path.join(directory,'identity.json');if(existsSync(file))copyFileSync(file,file+'.previous');
 writeJsonAtomic(file,{version:1,publicKey,protection:protect?'windows-dpapi':'file-permissions',privateKey:protect?dpapi(raw.toString('base64'),'Protect'):raw.toString('base64')});return openIdentity(directory,{protect});
}
