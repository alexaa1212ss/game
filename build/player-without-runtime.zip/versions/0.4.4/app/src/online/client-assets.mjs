// Pure browser patching. This module deliberately imports no server machinery.
const anchor='this.room=new d(window.location.protocol.replace("http","ws")+"//"+window.location.host+"/ws?world="+encodeURIComponent(window.CavegameWorldId||"survival"))';
export function sharedClientAsset(filename,text,endpoint){
 if(filename!=='/client.local.js')return text;
 for(const [from,to] of [[anchor,'this.room=new d(window.CavegameRemote.endpoint)'],['this.room.sessionId=t.data,this.room.removeAllListeners(),e.call(this)','this.room.sessionId=t.data,window.CavegameLocalId=t.data,this.room.removeAllListeners(),e.call(this)']]){
  if(text.split(from).length!==2)throw Error('Client connection patch anchor changed.');text=text.replace(from,to);
 }
 return text;
}
