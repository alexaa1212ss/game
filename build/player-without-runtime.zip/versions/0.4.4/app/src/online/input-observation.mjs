// Explicitly allowlisted observations; no chat text, keys, tokens or terrain.
const finite=v=>Number.isFinite(v)&&Math.abs(v)<Number.MAX_SAFE_INTEGER?v:null;
const integer=v=>Number.isSafeInteger(v)&&v>=0?Math.min(1e9,v):0;
export function inputObservation(value,id){
 if(!value||value.identityId!==id)throw Error('Diagnostic identity mismatch.');
 const counters=value.counters??{},sent={},received={};
 for(const name of ['move','pointer-data','leftmouse','rightmouse','space-bar','shift','server-ready','secretid','inventory-select'])sent[name]=integer(counters.sent?.[name]);
 for(const [key,n]of Object.entries(counters.received??{}).slice(0,64))if(/^\d{1,3}$/.test(key))received[key]=integer(n);
 const flags={};for(const name of ['roomJoined','focused','documentFocused','chatMode','spectating','buySearchFocused','sceneActive'])flags[name]=value.flags?.[name]===true;
 flags.menu=/^[a-z0-9-]{1,50}$/i.test(value.flags?.menu??'')?value.flags.menu:null;flags.activeTag=/^[A-Z]{1,16}$/.test(value.flags?.activeTag??'')?value.flags.activeTag:null;
 const applied=value.applied?Object.fromEntries(['x','y','spriteX','spriteY'].map(k=>[k,finite(value.applied[k])])):null;
 return {identityId:id,temporaryId:/^(?:r_[a-f0-9]{48}|[a-f0-9-]{36})$/.test(value.temporaryId??'')?value.temporaryId:null,counters:{keys:integer(counters.keys),pointers:integer(counters.pointers),canvasPointers:integer(counters.canvasPointers),sent,received},flags,applied,errors:(Array.isArray(value.errors)?value.errors:[]).slice(-10).map(e=>({at:integer(e.at),error:String(e.error??'').replace(/[\x00-\x1f]/g,' ').slice(0,300)}))};
}
