import path from 'node:path';import {existsSync} from 'node:fs';import {spawn} from 'node:child_process';
// Refresh only this product's existing per-user shortcuts after a signed update.
// No Explorer restart, registry/cache deletion, elevation or shortcut creation.
export function refreshWindowsIcon(install,icon){
 if(process.platform!=='win32'||!install||!existsSync(icon))return;
 const command="$ErrorActionPreference='Stop';$shell=New-Object -ComObject WScript.Shell;$expected=[IO.Path]::GetFullPath((Join-Path $env:REBORN_ICON_INSTALL 'Cavegame Reborn.exe'));foreach($folder in @([Environment]::GetFolderPath('DesktopDirectory'),[Environment]::GetFolderPath('Programs'))){$link=Join-Path $folder 'Cavegame Reborn.lnk';if(Test-Path -LiteralPath $link){$s=$shell.CreateShortcut($link);if([IO.Path]::GetFullPath($s.TargetPath) -eq $expected){$next=$env:REBORN_ICON_FILE+',0';if($s.IconLocation -ne $next){$s.IconLocation=$next;$s.Save()}}}}";
 const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-Command',command],{windowsHide:true,stdio:'ignore',env:{...process.env,REBORN_ICON_INSTALL:path.resolve(install),REBORN_ICON_FILE:path.resolve(icon)}});child.on('error',()=>{});child.unref();
}
