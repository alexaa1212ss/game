// Closed Alpha policy only. Offline and public-release callers opt out by omitting it.
import {createHash} from 'node:crypto';

export function alphaAgreementPolicy(value){
 if(value===undefined||value===null||value===false)return null;
 if(value===true)return CLOSED_ALPHA_AGREEMENT;
 if(!value||typeof value!=='object'||typeof value.version!=='string'||!/^[A-Za-z0-9._-]{1,64}$/.test(value.version)||typeof value.title!=='string'||value.title.length<1||value.title.length>160||!Array.isArray(value.paragraphs)||value.paragraphs.length<1||value.paragraphs.length>10||value.paragraphs.some(p=>typeof p!=='string'||!p.length||p.length>4000))throw Error('Invalid Closed Alpha agreement policy.');
 const paragraphs=Object.freeze([...value.paragraphs]),sha256=createHash('sha256').update(JSON.stringify({title:value.title,paragraphs})).digest('hex');
 if(value.sha256!==undefined&&value.sha256!==sha256)throw Error('Closed Alpha agreement content digest mismatch.');
 return Object.freeze({version:value.version,title:value.title,paragraphs,sha256});
}

export const CLOSED_ALPHA_AGREEMENT=alphaAgreementPolicy({
 version:'closed-alpha-1',
 title:'CAVEGAME REBORN — CLOSED ALPHA AGREEMENT',
 paragraphs:[
  'This is confidential pre-release software. By continuing, you agree not to leak, publish, share, copy, or redistribute the Alpha installer/download link, account access, unreleased media, private development information, or other confidential Alpha materials without authorization.',
  'Violations may result in immediate termination of Alpha access and may result in legal and/or court action where permitted by applicable law.'
 ]
});

export function hasAlphaAcceptance(receipt,identityId,policy){
 return !policy||receipt?.accepted===true&&receipt.identityId===identityId&&receipt.version===policy.version&&receipt.sha256===policy.sha256&&Number.isSafeInteger(receipt.acceptedAt)&&receipt.acceptedAt>0;
}

// Separate from the login signature: an older client signing a challenge with
// unknown fields must never be mistaken for an explicit agreement acceptance.
export function alphaAcceptanceMessage(challengeMessage,policy){
 return JSON.stringify({domain:'cavegame-reborn.alpha-agreement.v1',challenge:challengeMessage,version:policy.version,sha256:policy.sha256,decision:'I AGREE'});
}
