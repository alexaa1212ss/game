// Public wire compatibility constants; no permissions, accounts or secrets.
export const ONLINE_PROTOCOL=1;
export const ONLINE_VERSION=process.env.CAVEGAME_APP_VERSION??'0.2.2';
