import {createPublicKey,verify,createHash,randomUUID} from 'node:crypto';import {readFileSync,existsSync,mkdirSync,writeFileSync,renameSync,readdirSync,lstatSync,rmSync} from 'node:fs';import path from 'node:path';
import {writeJsonAtomic} from '../atomic-json.mjs';import {extractZip} from './zip.mjs';
export const validVersion=v=>typeof v==='string'&&/^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(v);
export function compareVersions(a,b){if(!validVersion(a)||!validVersion(b))throw Error('Invalid release version.');const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++)if(x[i]!==y[i])return x[i]>y[i]?1:-1;return 0;}
export function verifyRelease(manifest,publicKey,{product='RebornClient',now=Date.now(),installed=false}={}){
 const r=manifest?.release;if(!r||r.format!==1||r.product!==product||!validVersion(r.version)||!/^[a-zA-Z0-9._-]+\.zip$/.test(r.file)||!/^[a-f0-9]{64}$/.test(r.sha256)||!Number.isSafeInteger(r.bytes)||r.bytes<1||r.bytes>500*1024*1024||r.launcherVersion!==1)throw Error('Invalid update manifest.');
 const key=createPublicKey(publicKey);if(key.asymmetricKeyType!=='ed25519'||typeof manifest.signature!=='string'||manifest.signature.length>128||!verify(null,Buffer.from(JSON.stringify(r)),key,Buffer.from(manifest.signature,'base64')))throw Error('Update signature invalid.');
 if(!installed&&(!Number.isFinite(r.expiresAt)||r.expiresAt<=now||r.publishedAt>now+300000))throw Error('Update manifest expired or not yet valid.');return r;
}
const feedUrl=value=>{const u=new URL(value);if(u.username||u.password||u.hash||!['https:','http:'].includes(u.protocol)||u.protocol==='http:'&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname))throw Error('Updates require HTTPS (loopback testing excepted).');return u;};
export async function download(url,maxBytes,{timeout=120000,fresh=false}={}){
 let next=feedUrl(url),response;
 for(let redirects=0;redirects<=5;redirects++){
  response=await fetch(next,{signal:AbortSignal.timeout(timeout),redirect:'manual',...(fresh?{cache:'no-store',headers:{'Cache-Control':'no-cache','Pragma':'no-cache'}}:{})});
  if(![301,302,303,307,308].includes(response.status))break;
  await response.body?.cancel();if(redirects===5)throw Error('Too many download redirects.');
  const target=feedUrl(new URL(response.headers.get('location'),next).href);if(next.protocol==='https:'&&target.protocol!=='https:')throw Error('HTTPS downgrade rejected.');next=target;
 }
 if(!response.ok)throw Error('Update download failed: HTTP '+response.status);if(Number(response.headers.get('content-length'))>maxBytes)throw Error('Download too large.');const parts=[];let size=0;for await(const part of response.body){size+=part.length;if(size>maxBytes)throw Error('Download exceeds limit.');parts.push(part);}return Buffer.concat(parts);
}
export function verifyInstalledFiles(folder,release,{required=release.product==='RebornPlayer'}={}){
 if(!release.files){if(required)throw Error('Signed file inventory missing.');return true;}
 if(!Array.isArray(release.files)||release.files.length<2||release.files.length>10000)throw Error('Invalid signed file inventory.');
 const expected=new Map();for(const f of release.files){
  if(!f||typeof f.path!=='string'||f.path.length>240||! /^[a-zA-Z0-9_. /-]+$/.test(f.path)||f.path.startsWith('/')||f.path.split('/').some(p=>!p||p==='.'||p==='..')||expected.has(f.path)||!Number.isSafeInteger(f.bytes)||f.bytes<0||!/^[a-f0-9]{64}$/.test(f.sha256))throw Error('Invalid signed file entry.');expected.set(f.path,f);
 }
 const seen=new Set();function visit(directory,prefix=''){for(const e of readdirSync(directory,{withFileTypes:true})){
  const relative=prefix+e.name,absolute=path.join(directory,e.name);if(e.isSymbolicLink()||lstatSync(absolute).isSymbolicLink())throw Error('Installation links rejected.');
  if(e.isDirectory()){visit(absolute,relative+'/');continue;}if(relative==='trusted-release.json')continue;
  const f=expected.get(relative);if(!f)throw Error('Unexpected installed file: '+relative);const bytes=readFileSync(absolute);if(bytes.length!==f.bytes||createHash('sha256').update(bytes).digest('hex')!==f.sha256)throw Error('Installed file hash mismatch: '+relative);seen.add(relative);
 }}visit(folder);if(seen.size!==expected.size)throw Error('Installed files missing.');return true;
}
export class ReleaseUpdater{
 constructor({directory,product='RebornClient'}){this.directory=path.resolve(directory);this.product=product;this.key=readFileSync(path.join(directory,'release-public.pem'),'utf8');this.pointer=path.join(directory,'installed.json');this.busy=false;this.current();}
 current(){const p=JSON.parse(readFileSync(this.pointer,'utf8'));if(p.format!==1||!validVersion(p.current)||p.previous!==null&&!validVersion(p.previous))throw Error('Invalid installation pointer.');return p;}
 async manifest(url){const feed=feedUrl(url),data=JSON.parse((await download(feed,2*1024*1024)).toString());const release=verifyRelease(data,this.key,{product:this.product});return {data,release,url:feedUrl(release.artifactUrl??new URL(release.file,feed).href).href};}
 async check(url){const {release}=await this.manifest(url);return {available:compareVersions(release.version,this.current().current)>0,version:release.version,message:'Verified update channel.'};}
 async install(url){
  if(this.busy)throw Error('An update is already in progress.');this.busy=true;
  try{
   const {data,release,url:artifact}=await this.manifest(url),pointer=this.current();if(compareVersions(release.version,pointer.current)<=0)return {ok:true,message:'No newer version to install.'};
   const bytes=await download(artifact,release.bytes);if(bytes.length!==release.bytes||createHash('sha256').update(bytes).digest('hex')!==release.sha256)throw Error('Update archive hash mismatch.');
   const versions=path.join(this.directory,'versions'),staging=path.join(versions,'.stage-'+randomUUID()),target=path.join(versions,release.version);if(path.dirname(path.resolve(target))!==path.resolve(versions)||existsSync(target))throw Error('Version already exists; use rollback or a newer release.');
   try{extractZip(bytes,staging);const entry=path.join(staging,'app','scripts',this.product==='RebornServer'?'start-online-server.mjs':'start-online-client.mjs');if(!existsSync(entry)||!existsSync(path.join(staging,'runtime','node.exe')))throw Error('Update is missing its entry point or runtime.');
    verifyInstalledFiles(staging,release);writeJsonAtomic(path.join(staging,'trusted-release.json'),data);renameSync(staging,target);writeJsonAtomic(this.pointer,{format:1,current:release.version,previous:pointer.current,pending:this.product==='RebornPlayer'});
   }catch(error){if(existsSync(staging))rmSync(staging,{recursive:true,force:true});throw error;}
   return {ok:true,version:release.version,message:'Verified update installed. Leave your game, then click Restart client to use it.'};
  }finally{this.busy=false;}
 }
 rollback(){if(this.busy)throw Error('Update in progress.');const p=this.current();if(!p.previous)throw Error('No previous version is installed.');const folder=path.join(this.directory,'versions',p.previous),r=verifyRelease(JSON.parse(readFileSync(path.join(folder,'trusted-release.json'),'utf8')),this.key,{product:this.product,installed:true});if(r.version!==p.previous)throw Error('Rollback manifest does not match the installed version.');verifyInstalledFiles(folder,r);writeJsonAtomic(this.pointer,{format:1,current:p.previous,previous:p.current});return {ok:true,message:'Previous verified version selected. Restart the app.'};}
}
