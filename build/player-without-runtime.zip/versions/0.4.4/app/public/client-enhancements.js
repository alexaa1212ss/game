// Normal player rendering hook: terrain visibility is controlled by the server.
window.CavegameClient={xray:false,setXray(){return false;},attachGame(game){return game;}};
