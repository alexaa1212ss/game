// Connection recovery and bounded observations. No client gameplay authority.
(() => {
 const online=window.RebornOnline,originalFetch=window.fetch.bind(window);if(!online)return;
 let scene=null,room=null,recovering=false,retired=false;
 // The recovered client registers a beforeunload confirmation. An intentional
 // authenticated recovery must finish without waiting on that old page guard.
 // Capture runs before its bubble listener; ordinary manual exits retain it.
 let navigating=false;
 window.addEventListener('beforeunload',event=>{if(navigating)event.stopImmediatePropagation();},true);
 const counters={keys:0,pointers:0,canvasPointers:0,sent:{},received:{}},errors=[];
 const count=(group,key)=>group[key]=Math.min(1000000000,(group[key]||0)+1);
 online.observeScene=value=>{scene=value;};
 online.recordSent=(type,value)=>{room=value;count(counters.sent,type);};
 online.recordWire=(id,bytes)=>{count(counters.received,String(id));counters.lastPacketBytes=bytes;};
 online.inputDiagnostic=reason=>{errors.push({at:Date.now(),error:String(reason).slice(0,250)});if(errors.length>10)errors.shift();};
 for(const name of ['keydown','pointerdown'])window.addEventListener(name,event=>{if(name==='keydown'){if(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(event.code))counters.keys++;}else{counters.pointers++;if(event.target?.tagName==='CANVAS')counters.canvasPointers++;}},true);
 async function recover(){
  if(recovering||retired)return;recovering=true;
  try{
   const last=Number(sessionStorage.getItem('reborn-last-session-recovery')||0);if(Date.now()-last<30000)throw Error('Session recovery paused; reopen the launcher.');
   sessionStorage.setItem('reborn-last-session-recovery',String(Date.now()));
   const r=await originalFetch('/launcher/refresh-session',{method:'POST',headers:{'x-reborn-game':online.gameLease}}),d=await r.json();if(!r.ok)throw Error(d.error);online.inputDiagnostic('session-recovered');navigating=true;location.reload();
  }catch(error){online.inputDiagnostic(error.message);recovering=false;}
 }
 window.fetch=async(input,options={})=>{
  const url=new URL(typeof input==='string'?input:input.url,location.href),local=url.origin===location.origin;
  if(local&&(url.pathname.startsWith('/local/')||url.pathname.startsWith('/v1/')||url.pathname.startsWith('/launcher/'))){const headers=new Headers(input instanceof Request?input.headers:undefined);new Headers(options.headers).forEach((v,k)=>headers.set(k,v));headers.set('x-reborn-game',online.gameLease);options={...options,headers};}
  const response=await originalFetch(input,options);
  if(local&&!response.ok&&url.pathname!=='/launcher/input-report'){
   let data={};try{data=await response.clone().json();}catch{}
   online.inputDiagnostic(url.pathname+' HTTP '+response.status+': '+(data.error??''));
   if(data.code==='STALE_GAME_WINDOW'){retired=true;scene?.sendInputReset?.();navigating=true;location.replace(online.launcherUrl);}
   else if(response.status===403&&/^Session expired\./.test(data.error??''))void recover();
  }return response;
 };
 function observation(){const id=online.account.id,self=scene?.objs?.[id];return {identityId:id,temporaryId:window.CavegameLocalId,counters,flags:{roomJoined:!!scene?.roomJoined,focused:!!scene?.focused,documentFocused:document.hasFocus(),chatMode:!!scene?.chatMode,spectating:!!scene?.spectating,buySearchFocused:!!scene?.buySearchFocused,sceneActive:!!scene?.scene?.isActive('Game'),menu:window.CavegameUI?.current()??null,activeTag:document.activeElement?.tagName??null},applied:self?{x:self.x,y:self.y,spriteX:self.sprite?.x,spriteY:self.sprite?.y}:null,errors};}
 setInterval(()=>{if(retired)return;originalFetch('/launcher/input-report',{method:'POST',headers:{'Content-Type':'application/json','x-reborn-game':online.gameLease},body:JSON.stringify(observation())}).catch(()=>{});},5000);
})();
