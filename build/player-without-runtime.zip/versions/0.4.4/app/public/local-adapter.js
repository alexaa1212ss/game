window.CavegameLocalId=window.RebornOnline?.account?.id??crypto.randomUUID();
const localAuth={currentUser:null,onAuthStateChanged(callback){queueMicrotask(()=>callback(null));return()=>{};}};
window.CavegameLocalAuth={getAuth:()=>localAuth,getAnalytics:()=>null,GoogleAuthProvider:class{},signInWithPopup:()=>Promise.reject(Error('Your Reborn identity is already signed in.'))};
document.addEventListener('DOMContentLoaded',()=>{window.RebornOnline.menuReady();
 let attempts=0;const wait=setInterval(()=>{const play=document.getElementById('play-cavegame-io');if(play&&!play.disabled){clearInterval(wait);play.click();}else if(++attempts>150)clearInterval(wait);},100);
});
