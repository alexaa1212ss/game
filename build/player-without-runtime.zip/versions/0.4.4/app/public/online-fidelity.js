// Keep item tooltips outside scrolling crafting/shop containers. This never
// changes inventory order, capacity, input, item data or server authority.
(() => {
 if(!window.RebornOnline)return;
 function initialize(){
  if(document.getElementById('ro-item-tooltip'))return;
  const tooltip=document.createElement('div');tooltip.id='ro-item-tooltip';tooltip.className='item-tt no-select';
  tooltip.hidden=true;tooltip.setAttribute('role','tooltip');document.body.append(tooltip);
  document.body.classList.add('ro-tooltip-ready');
  let active=null,frame=0,craftFrame=0;
  function hide(){active=null;tooltip.hidden=true;if(frame){cancelAnimationFrame(frame);frame=0;}if(craftFrame){cancelAnimationFrame(craftFrame);craftFrame=0;}}
  function readableText(node){
   if(node.nodeType===3)return node.nodeValue||'';
   if(node.nodeType!==1)return '';
   if(node.tagName==='BR')return '\n';
   if(['SCRIPT','STYLE','IFRAME','OBJECT'].includes(node.tagName))return '';
   const text=Array.from(node.childNodes||[],readableText).join('');
   return node.tagName==='DIV'?'\n'+text+'\n':text;
  }
  function place(){
   frame=0;if(!active||!active.isConnected||!active.getClientRects().length){hide();return;}
   const bounds=active.getBoundingClientRect(),size=tooltip.getBoundingClientRect(),margin=12,gap=9;
   const width=document.documentElement.clientWidth||window.innerWidth,height=document.documentElement.clientHeight||window.innerHeight;
   const left=Math.max(margin,Math.min(width-size.width-margin,bounds.left+bounds.width/2-size.width/2));
   let top=bounds.top-size.height-gap;if(top<margin)top=bounds.bottom+gap;
   top=Math.max(margin,Math.min(height-size.height-margin,top));
   tooltip.style.left=Math.round(left)+'px';tooltip.style.top=Math.round(top)+'px';
  }
  document.addEventListener('pointerover',event=>{
   const item=event.target?.closest?.('.item-cont');
   if(!item||item.closest('#craft-modal')){hide();return;}
   if(item===active)return;
   const source=item.querySelector('.item-tt');if(!source){hide();return;}
   const text=readableText(source).replace(/\n[ \t]*\n+/g,'\n').trim();if(!text){hide();return;}
   active=item;tooltip.textContent=text;tooltip.hidden=false;place();
  });
  document.addEventListener('pointerout',event=>{
   if(active&&!active.contains(event.relatedTarget))hide();
  });
  document.addEventListener('pointermove',event=>{
   if(active&&!frame)frame=requestAnimationFrame(place);
   if(!event.target?.closest?.('#craft-modal .overlay-inventory'))return;
   const x=event.clientX,y=event.clientY;
   if(craftFrame)cancelAnimationFrame(craftFrame);
   craftFrame=requestAnimationFrame(()=>{
    craftFrame=0;const description=document.getElementById('crafting-desc');
    if(!description||!description.getClientRects().length)return;
    const size=description.getBoundingClientRect(),width=document.documentElement.clientWidth||window.innerWidth,height=document.documentElement.clientHeight||window.innerHeight;
    description.style.left=Math.max(12,Math.min(width-size.width-12,x+12))+'px';
    description.style.top=Math.max(12,Math.min(height-size.height-12,y-size.height-12))+'px';
   });
  });
  // A drag, menu switch or viewport change must not leave a detached tooltip.
  document.addEventListener('pointerdown',hide,true);
  document.addEventListener('scroll',hide,true);
  document.addEventListener('keydown',event=>{if(event.key==='Escape')hide();},true);
  window.addEventListener('blur',hide);window.addEventListener('resize',hide);
  document.addEventListener('cavegame-menu-change',hide);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize,{once:true});else initialize();
})();
