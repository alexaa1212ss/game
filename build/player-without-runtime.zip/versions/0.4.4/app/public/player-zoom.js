document.addEventListener('DOMContentLoaded',()=>{
 const bar=document.createElement('div');bar.className='rp-zoom';bar.setAttribute('aria-label','Camera zoom');
 for(const [label,factor]of [['−',.8],['1×',0],['+',1.25]]){const b=document.createElement('button');b.textContent=label;b.onclick=()=>{const api=window.CavegameView,state=api?.getState();if(state)api.setZoom(factor?state.zoom*factor:state.defaultZoom);b.blur();};bar.append(b);}document.body.append(bar);
 const style=document.createElement('style');style.textContent='.rp-zoom{position:fixed;top:12px;right:180px;z-index:900;display:flex;gap:4px}.rp-zoom button{padding:4px 9px;min-width:32px;font-size:14px}';document.head.append(style);
});
