// Presentation only: preserve native controls, IDs, listeners and saved state.
(() => {
  const $ = selector => document.querySelector(selector);
  function create(tag, className, text) {
    const node = document.createElement(tag); node.className = className;
    if (text) node.textContent = text;
    return node;
  }
  function overline(header, text) {
    const title = header?.querySelector('h2,strong');
    if (title && !header.querySelector('.cg-overline')) title.before(create('span','cg-overline',text));
  }
  function drawer(nodes, title, className) {
    const existing = nodes.filter(Boolean); if (!existing.length) return;
    const detail = create('details', 'cg-drawer ' + className);
    const summary = create('summary', '', title); detail.append(summary);
    existing[0].before(detail);
    const body = create('div', 'cg-drawer-body'); detail.append(body);
    body.append(...existing); return detail;
  }
  function icon(button, name) {
    if (!button || button.querySelector('.cg-button-icon')) return;
    const image = create('img','cg-button-icon'); image.src='/asset/scaled/'+name+'.png'; image.alt='';
    button.prepend(image);
  }
  function mainMenu() {
    const center = $('#logo-container')?.closest('.modal'); if (!center) return;
    center.classList.add('cg-join-panel');
    $('#logo-container').append(create('span','cg-reborn-wordmark','R E B O R N'));
    center.prepend(create('span','cg-overline cg-save-label','YOUR WORLD. YOUR NEXT ADVENTURE.'));
    const nickname=$('#nickname');
    if(nickname){const label=create('label','cg-field-label','Adventurer name');label.htmlFor=nickname.id;nickname.before(label);}
    const graphics=$('#select-graphics');
    if(graphics){const label=create('label','cg-field-label','Graphics');label.htmlFor=graphics.id;graphics.before(label);}
    // Put the existing join action after world selection; its native handler stays attached.
    const form=center.querySelector('form'),play=$('#main-play-btn-cont');if(form&&play)form.append(play);
    $('#world-manage')?.classList.add('cg-secondary');
    const help=$('.how-to-play');
    if(help){
      const heading=[...help.querySelectorAll('h4')].find(n=>/changelog/i.test(n.textContent));
      if(heading){
        const archive=create('details','cg-history');archive.append(create('summary','','Original game changelog'));
        const body=create('div','cg-history-body');let node=heading.nextSibling;
        while(node){const next=node.nextSibling;body.append(node);node=next;}
        heading.replaceWith(archive);body.prepend(heading);archive.append(body);
      }
      help.prepend(create('span','cg-overline','THE ADVENTURER’S GUIDE'));
      const shortcuts=create('div','cg-shortcut-guide');
      for(const [key,label] of [['E','Craft'],['C','Creative'],['G','Gold Empire'],['F4','WorldEdit'],['X','X-ray'],['Ctrl + wheel','Zoom']]){
        const row=create('div','');row.append(create('kbd','',key),create('span','',label));shortcuts.append(row);
      }
      $('#menu-instructions')?.after(shortcuts);
    }
    $('#local-notice')?.classList.add('cg-save-notice');
  }
  function creative() {
    const panel=$('#creative-menu');if(!panel)return;
    overline(panel.querySelector('header'),'THE BUILDER’S WORKSHOP');
    drawer([$('.creative-settings'),$('.creative-travel'),$('.creative-equipment')], 'Workshop controls · gear, flight & teleport', 'cg-creative-controls');
    const tabs=$('#creative-tabs'),search=$('#creative-search'),grid=$('#creative-grid');if(!tabs||!grid)return;
    const workspace=create('div','cg-creative-workspace');tabs.before(workspace);
    const rail=create('aside','cg-catalog-rail');rail.append(create('span','cg-overline','COLLECTION'),tabs);
    const railArt=create('div','cg-workshop-emblem');railArt.innerHTML='<img src="/asset/scaled/table.png" alt=""><strong>Build something great.</strong><span>Every block starts an idea.</span>';rail.append(railArt);
    const content=create('div','cg-catalog-content');const searchRow=create('div','cg-catalog-search');
    searchRow.append(search,$('.creative-sort-label'));
    content.append(searchRow,$('#creative-feedback'),grid,$('#creative-inspector'));
    workspace.append(rail,content);
    const icons={all:'crate',items:'pick_diamond',blocks:'stone',mobs:'goblin',enchantments:'enchantment_table',favorites:'golden-compass',recent:'map',prototypes:'diamond'};
    for(const button of tabs.children)icon(button,icons[button.dataset.category]||'crate');
  }
  function empire() {
    const panel=$('#empire-panel');if(!panel)return;
    overline(panel.querySelector('header'),'A FORTUNE BUILT BLOCK BY BLOCK');
    icon($('#empire-tabs [data-tab="dashboard"]'),'gold');
    icon($('#empire-tabs [data-tab="research"]'),'enchantment_table');
    icon($('#empire-tabs [data-tab="leaderboard"]'),'golden-compass');
    drawer([$('#empire-wallet')], 'Treasury · deposit & withdraw gold', 'cg-treasury');
  }
  function worlds() {
    const panel=$('#world-management');if(!panel)return;
    overline(panel.querySelector('header'),'CHOOSE YOUR NEXT CHAPTER');
    const reset=$('.wm-reset');if(reset)drawer([reset],'Reset world & season settings','cg-danger-drawer');
    const form=$('#wm-form');if(form)form.classList.add('cg-create-world');
    icon($('#wm-random'),'mysterious-map');
    icon($('#wm-form button[type="submit"]'),'map');
  }
  function editor() {
    overline($('#world-editor .we-header'),'THE WORLD IS YOUR CANVAS');
    const icons={brush:'stone',erase:'pick_iron',select:'map',eyedropper:'golden-compass',paste:'crate'};
    for(const button of document.querySelectorAll('#world-editor [data-tool]'))icon(button,icons[button.dataset.tool]||'stone');
    icon($('#we-fit'),'map');icon($('#we-player'),'golden-compass');
  }
  function camera() {
    const controls=$('#player-view-controls');if(!controls)return;
    const existing=[...controls.children],dock=create('details','cg-camera-dock');
    const summary=create('summary','','Camera');summary.title='Zoom & flight controls. Ctrl + wheel also zooms while this panel is closed.';
    summary.addEventListener('click',event=>{if(event.detail>0)summary.blur();});
    const shortcut=create('span','cg-camera-shortcut','Ctrl + wheel');summary.append(shortcut);
    const body=create('div','cg-camera-body');body.append(...existing);dock.append(summary,body);controls.append(dock);
  }
  function boot() {
    document.body.classList.add('cg-art-edition');
    mainMenu();creative();empire();worlds();editor();camera();
    const editorLaunch=$('#worldedit-launch'),toolbar=$('#creative-toolbar');if(editorLaunch&&toolbar)toolbar.append(editorLaunch);
    for(const [selector,image]of [['#creative-open','crate'],['#local-spawn','map'],['#empire-launch','gold'],['#worldedit-launch','table']])icon($(selector),image);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
