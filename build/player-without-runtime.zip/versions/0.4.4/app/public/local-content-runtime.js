// Included after an inert JSON declaration by scripts/build-local-content.py.
(() => {
  const content=window.CavegameContent;
  content.initializeItem=item=>{
    const info=content.items[item.type];if(!info)return;
    Object.assign(item,{genericType:info.genericType,text:info.text,description:info.description,stackable:info.stackable,static:info.static&&!item.forceNonStatic,enchantable:info.enchantable,upgradeLevel:info.upgradeLevel??0,breakTime:info.breakTimeMs??null});
    item.key=info.textureKey??item.type+(info.enchantable&&item.isEnchanted()?'-enchanted':'');item.image=info.enchantable&&item.isEnchanted()?info.imageTemplate.replace(".svg","-enchanted.svg"):info.imageTemplate;item.handKey=item.key;if(info.placeable)item.blockType=info.blockType;
  };
  content.preload=scene=>{
    for(const item of Object.values(content.items)){const key=item.textureKey??item.type;scene.load.svg(key,item.imageTemplate,{width:64,height:64});if(item.enchantable)scene.load.svg(item.type+'-enchanted',item.imageTemplate.replace('.svg','-enchanted.svg'),{width:64,height:64});}
    scene.load.svg('arc-bolt','/asset/reborn/arc-bolt.svg',{width:22,height:22});
    scene.load.svg('player-aethersteel','/asset/reborn/player-aethersteel.svg',{width:64,height:64});
  };
})();
