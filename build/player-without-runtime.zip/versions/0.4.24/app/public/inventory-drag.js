// Slot presentation only. The server owns every item, quantity and saved layout.
(() => {
 const online=window.RebornOnline;if(!online)return;
 let scene=null,drag=null,frame=0,lastPoint=null,suppressClickUntil=0;
 const observe=online.observeScene;
 online.observeScene=function(value){scene=value;return observe?.call(this,value);};
 const slotOf=node=>node?.closest?.('#main-inventory .inv-drag,#hidden-inventory .inv-drag');
 const enabled=()=>scene?.roomJoined&&!scene.chestVisible&&!scene.spectating&&!window.CavegameUI?.current();
 function targetAt(x,y){const slot=slotOf(document.elementFromPoint(x,y));return slot?.getClientRects().length?slot:null;}
 function clear(){
  if(frame){cancelAnimationFrame(frame);frame=0;}
  if(!drag)return;drag.item.classList.remove('nl-inventory-dragging');drag.target?.classList.remove('nl-inventory-drop-target');drag.ghost?.remove();
  try{if(drag.item.hasPointerCapture(drag.pointer))drag.item.releasePointerCapture(drag.pointer);}catch{}
  drag=null;lastPoint=null;
 }
 function paint(){
  frame=0;if(!drag?.active||!lastPoint)return;
  drag.ghost.style.transform=`translate3d(${Math.round(lastPoint.x-drag.offsetX)}px,${Math.round(lastPoint.y-drag.offsetY)}px,0)`;
  const target=targetAt(lastPoint.x,lastPoint.y);
  if(target!==drag.target){drag.target?.classList.remove('nl-inventory-drop-target');drag.target=target;if(target&&target!==drag.source)target.classList.add('nl-inventory-drop-target');}
 }
 document.addEventListener('pointerdown',event=>{
  if(event.button!==0||!enabled())return;
  const item=event.target?.closest?.('.item-cont'),source=slotOf(item);
  if(!item||!source||source.firstElementChild!==item||!item.dataset.id)return;
  clear();const bounds=item.getBoundingClientRect();
  drag={item,source,pointer:event.pointerId,startX:event.clientX,startY:event.clientY,offsetX:event.clientX-bounds.x,offsetY:event.clientY-bounds.y,width:bounds.width,height:bounds.height,active:false,target:null,ghost:null};
  // Cancel compatibility mouse events so the old sortable cannot reorder cells
  // while this handler swaps the item nodes inside their fixed slots.
  event.preventDefault();event.stopImmediatePropagation();
  try{item.setPointerCapture(event.pointerId);}catch{}
 },true);
 document.addEventListener('pointermove',event=>{
  if(!drag||drag.pointer!==event.pointerId)return;
  if(!enabled()||!drag.item.isConnected){clear();return;}
  lastPoint={x:event.clientX,y:event.clientY};
  if(!drag.active&&Math.hypot(event.clientX-drag.startX,event.clientY-drag.startY)>=6){
   drag.active=true;drag.item.classList.add('nl-inventory-dragging');
   const ghost=drag.ghost=drag.item.cloneNode(true);ghost.id='inventory-drag-ghost';ghost.removeAttribute('data-id');ghost.setAttribute('aria-hidden','true');Object.assign(ghost.style,{width:drag.width+'px',height:drag.height+'px'});document.body.append(ghost);
  }
  if(drag.active){event.preventDefault();event.stopImmediatePropagation();if(!frame)frame=requestAnimationFrame(paint);}
 },{capture:true,passive:false});
 document.addEventListener('pointerup',event=>{
  if(!drag||drag.pointer!==event.pointerId)return;
  const state=drag,target=targetAt(event.clientX,event.clientY);
  if(state.active){
   event.preventDefault();event.stopImmediatePropagation();suppressClickUntil=performance.now()+250;
   if(enabled()&&target&&target!==state.source&&state.item.parentElement===state.source&&target.children.length<=1){
    const other=target.firstElementChild;
    if(!other||other.classList.contains('item-cont')){
     // Append retains original nodes/listeners; only these two slots change.
     if(other)state.source.append(other);target.append(state.item);
     scene.handleSortableUpdate(true);
    }
   }
  }else if(enabled()&&!scene.inventoryOverlayVisible&&state.source.parentElement?.id==='main-inventory'){
   scene.selectInventoryNumber([...state.source.parentElement.children].indexOf(state.source));
  }
  clear();
 },true);
 document.addEventListener('click',event=>{if(performance.now()<suppressClickUntil&&slotOf(event.target)){event.preventDefault();event.stopImmediatePropagation();}},true);
 document.addEventListener('pointercancel',clear,true);
 document.addEventListener('keydown',event=>{if(event.key==='Escape')clear();},true);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)clear();});
 document.addEventListener('cavegame-menu-change',clear);
 window.addEventListener('blur',clear);window.addEventListener('pagehide',clear);
})();
