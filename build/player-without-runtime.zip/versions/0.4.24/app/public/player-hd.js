// Use the recovered renderer's native graphics modes, preserving its camera/input scaling.
(()=>{const ratio=Math.max(1,Number(window.devicePixelRatio)||1),recommended=ratio>=1.75?'2160':ratio>=1.2?'1440':'1080';
 try{if(localStorage.getItem('reborn-hd-default-v1')!=='1'){localStorage.setItem('graphics',recommended);localStorage.setItem('reborn-hd-default-v1','1');}}catch{}
 window.RebornDisplay={nativeGraphics:true,recommendedHeight:Number(recommended),devicePixelRatio:ratio,maxHeight:2160};
})();
