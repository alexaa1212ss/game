// Existing authenticated Online APIs, displayed inside the Journal.
// This module never creates, replaces or exports an account identity.
(()=>{
 window.NoLifeJournalOnline=({U,identityRoot,clansRoot,notify})=>{
  const {el,progress}=U,online=window.RebornOnline;
  let self=null,busy=false,lastTab='',identityAt=0,identityPending=false,clanPending=false;
  const request=async(route,body)=>{
   const response=await fetch(route,{method:body?'POST':'GET',cache:'no-store',headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined});
   const data=await response.json();if(!response.ok)throw Error(data.error||'Could not complete this action.');return data;
  };
  function field(title,value){const row=el('div','nl-identity-field');row.append(el('dt','nl-muted',title),el('dd','',value));return row;}
  async function identity(){
   if(!online||identityPending||Date.now()-identityAt<15000)return;
   identityPending=true;
   try{
    self=await request('/v1/self');identityAt=Date.now();
    const signature=JSON.stringify([self.id,self.nickname,self.rank,self.clan?.id,self.warnings]);
    if(identityRoot.dataset.signature===signature)return;identityRoot.dataset.signature=signature;identityRoot.hidden=false;
    const heading=el('div','nl-section-heading'),mark=el('span','nl-identity-mark','ID'),copy=el('div');copy.append(el('h3','','My Identity'),el('p','nl-muted','Your verified character in this shared world.'));heading.append(mark,copy);
    const fields=el('dl','nl-identity-fields');fields.append(field('Nickname',self.nickname),field('Account role',self.rank),field('Clan',self.clan?'['+self.clan.tag+'] '+self.clan.name:'No clan yet'),field('Account ID',self.id));
    identityRoot.replaceChildren(heading,fields,el('p','nl-muted','This account ID identifies your character. Keep your recovery code private.'));
    for(const warning of self.warnings??[])identityRoot.append(el('p','nl-warning','Warning: '+warning.reason));
   }catch(error){identityRoot.hidden=false;identityRoot.replaceChildren(el('h3','','My Identity'),el('p','nl-muted','Identity is temporarily unavailable. '+error.message));}
   finally{identityPending=false;}
  }
  function input(label,placeholder,maxLength){const wrap=el('label','nl-field',label),node=el('input');node.type='text';node.placeholder=placeholder;node.maxLength=maxLength;wrap.append(node);return {wrap,node};}
  function action(label,body,{danger=false,confirm=false}={}){
   const button=el('button','nl-button'+(danger?' nl-danger':''),label);button.type='button';let armedUntil=0;
   button.onclick=async()=>{
    if(busy)return;
    if(confirm&&Date.now()>armedUntil){armedUntil=Date.now()+5000;button.textContent='Confirm '+label.toLowerCase();setTimeout(()=>{if(button.isConnected&&Date.now()>=armedUntil)button.textContent=label;},5100);return;}
    busy=true;button.disabled=true;U.sound('click');
    try{await request('/v1/clans',typeof body==='function'?body():body);notify('Clan changes saved.');identityAt=0;await Promise.all([clans(),identity()]);}
    catch(error){notify(error.message,true);}
    finally{busy=false;if(button.isConnected){button.disabled=false;button.textContent=label;}}
   };return button;
  }
  function directory(rows){
   const section=el('section','nl-clan-directory'),head=el('div','nl-section-heading'),title=el('h3','','Clans in this world'),search=input('Find a clan','Search name or tag',40),list=el('div','nl-clan-list'),empty=el('p','nl-empty','No clans match your search.');search.node.type='search';head.append(title,search.wrap);section.append(head,list,empty);
   const cards=rows.slice().sort((a,b)=>b.members-a.members||a.tag.localeCompare(b.tag)).map(clan=>{const card=el('article','nl-card nl-clan-row'),tag=el('span','nl-clan-tag','['+clan.tag+']'),copy=el('div');copy.append(el('strong','',clan.name),el('small','nl-muted',clan.members+' / 20 members'));card.append(tag,copy);list.append(card);return {card,text:(clan.tag+' '+clan.name).toLowerCase()};});
   const filter=()=>{let count=0;for(const item of cards){item.card.hidden=!item.text.includes(search.node.value.trim().toLowerCase());if(!item.card.hidden)count++;}empty.hidden=count>0;empty.textContent=rows.length?'No clans match your search.':'Be the first to start a clan.';};search.node.oninput=filter;filter();return section;
  }
  async function clans(){
   if(!online||clanPending)return;clanPending=true;clansRoot.setAttribute('aria-busy','true');
   try{
    const data=await request('/v1/clans'),content=el('div','nl-clans-content');
    content.append(el('h3','','Better together'),el('p','nl-muted','Find your people, share a banner, and explore the same world.'));
    if(data.clan){
     const clan=data.clan,owner=clan.owner===(self?.id??online.account.id),card=el('section','nl-card nl-clan-home'),heading=el('div','nl-section-heading'),crest=el('span','nl-clan-crest',clan.tag),copy=el('div');copy.append(el('span','nl-eyebrow',owner?'Your clan - leader':'Your clan'),el('h3','',clan.name),el('p','nl-muted',clan.members.length+' / 20 members'));heading.append(crest,copy);card.append(heading,progress(clan.members.length/20*100,'Clan member capacity'));
     if(owner){const target=input('Invite a player','Exact nickname or account ID',80),form=el('form','nl-clan-form');form.onsubmit=e=>e.preventDefault();form.append(target.wrap,action('Send invite',()=>({action:'invite',target:target.node.value.trim()})));card.append(form);}
     const details=el('details','nl-clan-members'),summary=el('summary','','Members and clan controls');details.append(summary);const members=el('ul');
     const names=new Map((data.memberProfiles??[]).map(p=>[p.id,p.nickname]));for(const id of clan.members){const row=el('li'),me=id===(self?.id??online.account.id);row.append(el('span','',me?'You':names.get(id)||('Member '+id.slice(0,12)+'...')),el('span','nl-badge',id===clan.owner?'Leader':'Member'));if(owner&&!me){row.append(action('Transfer leadership',{action:'transfer',target:id},{confirm:true}),action('Remove',{action:'kick',target:id},{danger:true,confirm:true}));}members.append(row);}details.append(members);card.append(details);
     const controls=el('div','nl-clan-actions');controls.append(action('Leave clan',{action:'leave'},{danger:true,confirm:true}));if(owner)controls.append(action('Disband clan',{action:'disband'},{danger:true,confirm:true}));card.append(controls);content.append(card);
    }else{
     const card=el('section','nl-card nl-clan-home'),tag=input('Clan tag','2-8 letters or numbers',8),name=input('Clan name','Choose your banner name',32),form=el('form','nl-clan-form');form.onsubmit=e=>e.preventDefault();card.append(el('h3','','Start your own story'),el('p','nl-muted','Make a clan, then invite up to 19 other players.'));form.append(tag.wrap,name.wrap,action('Create clan',()=>({action:'create',tag:tag.node.value.trim(),name:name.node.value.trim()})));card.append(form);content.append(card);
    }
    if(data.invites?.length){const invites=el('section','nl-clan-invites');invites.append(el('h3','','You are invited'));for(const invite of data.invites){const row=el('article','nl-card nl-clan-row');row.append(el('strong','','['+invite.tag+'] '+invite.name),action('Join clan',{action:'accept',clanId:invite.id}));invites.append(row);}content.append(invites);}
    content.append(directory(data.clans??[]));clansRoot.replaceChildren(content);
   }catch(error){clansRoot.replaceChildren(el('h3','','Clans'),el('p','nl-warning',error.message));const retry=el('button','nl-button','Try again');retry.onclick=clans;clansRoot.append(retry);}
   finally{clanPending=false;clansRoot.removeAttribute('aria-busy');}
  }
  if(!online){clansRoot.append(el('h3','','Clans'),el('p','nl-muted','Clans are available when connected to the Online world.'));return {render(){}};}
  identityRoot.hidden=false;identityRoot.append(el('h3','','My Identity'),el('p','nl-muted','Loading your verified character...'));
  return {render(tab){if(tab==='dashboard')void identity();if(tab==='clans'&&lastTab!==tab)void clans();lastTab=tab;}};
 };
})();
