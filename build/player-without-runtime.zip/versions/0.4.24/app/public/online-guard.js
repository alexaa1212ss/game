// Validate untrusted server bytes before entering the recovered client's decoder.
// Uses the same trusted local schema and deferred-array ordering as the server.
(() => {
 const online=window.RebornOnline,schemas=new Map(online.schemas.map(s=>[s.id,s])),keys=new WeakMap();let budgetAt=Date.now(),packets=0;
 const numeric={int8:[1,'getInt8'],uint8:[1,'getUint8'],int16:[2,'getInt16'],uint16:[2,'getUint16'],int32:[4,'getInt32'],uint32:[4,'getUint32'],float32:[4,'getFloat32'],float64:[8,'getFloat64']};
 online.acceptPacket=input=>{
  try{
   if(!(input instanceof ArrayBuffer)||input.byteLength<1||input.byteLength>1024*1024)return false;
   const time=Date.now();if(time-budgetAt>=1000){budgetAt=time;packets=0;}if(++packets>300)return false;
   const bytes=new Uint8Array(input),view=new DataView(input),packet=schemas.get(bytes[0]);if(!packet||packet.clientAllowed&&packet.id!==54&&packet.id!==55)return false;let offset=0,cells=0;
   const take=n=>{if(!Number.isSafeInteger(n)||n<0||offset+n>bytes.length)throw Error();const start=offset;offset+=n;return start;};
   const variable=()=>{let value=0,factor=1;for(let i=0;i<5;i++,factor*=128){const byte=bytes[take(1)];value+=(byte&127)*factor;if(value>2147483647)throw Error();if(!(byte&128))return value;}throw Error();};
   const walk=(schema,repeated=false)=>{
    if(++cells>30000)throw Error();
    if(Array.isArray(schema)){const n=variable();if(n>(packet.id===54?19:4096))throw Error();for(let i=0;i<n;i++)walk(schema[0],true);return;}
    if(typeof schema==='object'){let pair=keys.get(schema);if(!pair){const sorted=Object.keys(schema).sort();pair=[sorted,[...sorted.filter(k=>!Array.isArray(schema[k])),...sorted.filter(k=>Array.isArray(schema[k])).reverse()]];keys.set(schema,pair);}for(const key of pair[repeated?1:0])walk(schema[key],repeated);return;}
    if(schema==='string'){const n=variable();if(n>(packet.id===54?64:4096))throw Error();take(n);return;}
    if(schema==='varint'||schema==='varuint'){variable();return;}
    if(schema==='bool'||schema==='boolean'){if(bytes[take(1)]>1)throw Error();return;}
    const type=numeric[schema];if(!type)throw Error();const value=view[type[1]](take(type[0]),false);if(!Number.isFinite(value))throw Error();
   };
   walk(packet.schema);return offset===bytes.length;
  }catch{return false;}
 };
})();
