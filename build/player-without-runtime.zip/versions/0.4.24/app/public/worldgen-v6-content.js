// Safe block metadata/art only. No server generation code or hidden map data.
(()=>{const content=window.CavegameContent??(window.CavegameContent={version:1,items:{},blocks:[],initializeItem(){},preload(){}}),added=[
 {blockType:44,key:'mineshaft-floor',text:'Timber Walkway',walkable:true,seeable:false,hasTransparency:false,dropType:null,isItem:false,placeable:false,mineable:false},
 {blockType:45,key:'mineshaft-wall',text:'Mineshaft Timber Wall',walkable:false,seeable:false,hasTransparency:false,dropType:'sticks',isItem:false,placeable:false}
];content.blocks=[...(content.blocks??[]).filter(b=>b.blockType!==44&&b.blockType!==45),...added];const previous=content.preload;content.preload=scene=>{previous?.(scene);scene.load.svg('tile44','/asset/worldgen-v6/wood-floor.svg',{width:64,height:64});scene.load.svg('tile45','/asset/worldgen-v6/wood-wall.svg',{width:64,height:64});};})();
