// Server-announced, static spawn apron. Four rectangles, no map fetch or HUD interception.
(()=>{
 const online=window.RebornOnline,z=online?.spawnZone;if(!z)return;
 const previous=online.observeScene;
 online.observeScene=scene=>{
  previous?.(scene);
  const g=scene.add.graphics().setDepth(1),unit=scene.blockSize||64,o=z.outer,i=z.inner;
  g.fillStyle(0x8b9096,.14);
  for(const [x,y,w,h]of [[o.xMin,o.yMin,o.xMax-o.xMin,i.yMin-o.yMin],[o.xMin,i.yMax,o.xMax-o.xMin,o.yMax-i.yMax],[o.xMin,i.yMin,i.xMin-o.xMin,i.yMax-i.yMin],[i.xMax,i.yMin,o.xMax-i.xMax,i.yMax-i.yMin]])g.fillRect(x*unit,y*unit,w*unit,h*unit);
  g.lineStyle(2,0xc6cbd0,.3);g.strokeRect(o.xMin*unit,o.yMin*unit,(o.xMax-o.xMin)*unit,(o.yMax-o.yMin)*unit);
 };
})();
