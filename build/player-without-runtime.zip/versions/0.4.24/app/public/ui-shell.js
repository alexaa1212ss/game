// Shared modal ownership. The recovered game remains responsible for its HUD.
(() => {
  const registered = new Map();
  let active = null, previousFocus = null, scrim = null;
  const focusables = element => [...element.querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],summary,[tabindex="0"]')].filter(node => !node.hidden && !node.closest('[hidden]') && node.checkVisibility?.({checkVisibilityCSS:true}) !== false);
  function ensureScrim() {
    if (scrim) return;
    scrim = document.createElement('div'); scrim.id = 'cg-menu-scrim'; scrim.hidden = true;
    scrim.setAttribute('aria-hidden', 'true');
    scrim.addEventListener('pointerdown', event => { event.preventDefault(); event.stopPropagation(); });
    document.body.append(scrim);
  }
  function announce(id, open) { document.dispatchEvent(new CustomEvent('cavegame-menu-change', {detail:{id,open}})); }
  function close(id = active) {
    if (!id || active !== id) return;
    const entry=registered.get(id);
    entry?.element.classList.remove('cg-modal-current');
    active = null; if (scrim) scrim.hidden = true; document.body.classList.remove('cg-menu-open');
    announce(id, false);
    if(entry?.returnFocus==='game'){
      document.activeElement?.blur();
      const canvas=document.querySelector?.('canvas');
      if(canvas&&!canvas.closest('[hidden]')){canvas.setAttribute('tabindex','-1');canvas.focus({preventScroll:true});}
      window.CavegameView?.resetInput?.();
    }
    else if (previousFocus?.isConnected && !previousFocus.closest('[hidden]')) previousFocus.focus({preventScroll:true});
    else document.activeElement?.blur();
    previousFocus = null;
  }
  function open(id) {
    const entry = registered.get(id); if (!entry || active === id) return;
    const prior = active;
    if (prior) { registered.get(prior)?.close?.(); close(prior); }
    ensureScrim(); previousFocus = document.activeElement; active = id;
    scrim.hidden = false; document.body.classList.add('cg-menu-open');
    entry.element.classList.add('cg-modal-current'); entry.element.setAttribute('tabindex','-1');
    window.CavegameView?.resetInput?.(); announce(id, true);
    requestAnimationFrame(() => { if(active !== id)return; const target = typeof entry.initialFocus === 'function' ? entry.initialFocus() : entry.initialFocus; (target || focusables(entry.element)[0] || entry.element).focus({preventScroll:true}); });
  }
  window.CavegameUI = {
    register(id, options) {
      if(!id || !options?.element || typeof options.close !== 'function')throw Error('A menu needs an element and a close callback.');
      // Let controls receive their own events, then stop them before the game's
      // document/window listeners. Capturing all keys would break tree arrows.
      const stop=event=>event.stopPropagation();
      for(const type of ['keydown','keyup','pointerdown','mousedown','wheel'])options.element.addEventListener(type,stop);
      registered.set(id,options);
      return () => { close(id); registered.delete(id); for(const type of ['keydown','keyup','pointerdown','mousedown','wheel'])options.element.removeEventListener(type,stop); };
    },
    open, close, current: () => active,
    isTextTarget: target => ['INPUT','TEXTAREA','SELECT'].includes(target?.tagName) || !!target?.isContentEditable
  };
  function fitMainMenu() {
    if (!document.body) return;
    const width=window.innerWidth||document.documentElement?.clientWidth||1200;
    document.body.classList[width<1050?'add':'remove']('cg-compact-menu');
  }
  window.addEventListener('resize',fitMainMenu);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',fitMainMenu);else fitMainMenu();
  window.addEventListener('keydown', event => {
    if (!active) return;
    const entry = registered.get(active); if(!entry)return;
    // A destructive-operation confirmation owns its native focus trap and Esc.
    if (entry.element.querySelector?.('dialog[open]')) return;
    if(event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); if(entry.onEscape?.(event)!==true)entry.close(); return; }
    if(event.key === 'Tab') {
      const items = focusables(entry.element), index = items.indexOf(document.activeElement);
      event.preventDefault();
      if(items.length)items[index < 0 ? (event.shiftKey ? items.length - 1 : 0) : (index + (event.shiftKey ? -1 : 1) + items.length) % items.length].focus({preventScroll:true});
      else entry.element.focus({preventScroll:true});
    }
    // Text editing shortcuts and modal navigation stay inside the open panel.
    if (!entry.element.contains(event.target)) event.stopImmediatePropagation();
  }, true);
})();
