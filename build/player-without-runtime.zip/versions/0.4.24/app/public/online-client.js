(() => {
 const online=window.RebornOnline;
 online.menuReady=()=>{
  document.body.classList.add('reborn-online');
  document.title='Cavegame Reborn Online';const note=document.getElementById('local-notice');if(note)note.textContent='SURVIVAL · Server-saved progress'+' · G Journal';
  localStorage.setItem('nickname',online.account.nickname);const nickname=document.getElementById('nickname');if(nickname){nickname.maxLength=20;nickname.value=online.account.nickname;nickname.readOnly=true;}
  for(const id of ['sign-in-google','sign-out-google','sign-in-game-text','secret-ip-container','ranks']){const e=document.getElementById(id);if(e)e.style.display='none';}
  const left=document.querySelector('#menu-table td:first-child .mini-modal');if(left){const h=document.createElement('h3'),p=document.createElement('p');h.textContent='REBORN ONLINE '+online.version;p.textContent='One shared world. Your progress saves automatically. Press G for your Journal, achievements, clans and identity.';left.replaceChildren(h,p);}
  const links=document.getElementById('bottom-links');if(links){const a=document.createElement('a');a.href=online.launcherUrl;a.textContent='Reborn Launcher · Updates · Identity Recovery';links.replaceChildren(a);}
  const info=document.getElementById('important-server-info');if(info)info.textContent='Online identity verified · '+online.account.nickname+' · '+online.account.rank;
  const form=document.querySelector('#menu-table form');if(form){const p=document.createElement('p');p.textContent=online.account.developer?'Developer permissions verified by the server. /devhelp':'Connected as '+online.account.nickname+'. Your nickname and inventory are server-controlled.';const back=document.createElement('a');back.href=online.launcherUrl;back.textContent='Launcher / Updates / Recovery';form.append(p,back);}
  if(!online.account.developer&&window.CavegameClient){window.CavegameClient.setXray(false);const previous=window.CavegameClient.setXray;window.CavegameClient.setXray=value=>previous(false);}
 };
 document.addEventListener('DOMContentLoaded',()=>{
  const style=document.createElement('link');style.rel='stylesheet';style.href='/online.css';document.head.append(style);
  setInterval(()=>fetch('/launcher/heartbeat').catch(()=>{}),10000);
 });
})();
