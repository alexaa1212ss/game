import {createPublicKey,verify} from 'node:crypto';
import {download} from './update.mjs';
import {existsSync,readFileSync} from 'node:fs';
import {writeJsonAtomic} from '../atomic-json.mjs';
export function verifyDeployment(envelope,key,{now=Date.now()}={}){
 const d=envelope?.deployment;if(!d||d.format!==1||d.product!=='RebornPlayer'||d.protocol!==1||!Number.isSafeInteger(d.expiresAt)||!Number.isSafeInteger(d.publishedAt)||d.publishedAt<0||d.expiresAt<=d.publishedAt||d.expiresAt<=now||d.publishedAt>now+300000)throw Error('Official server directory expired or invalid.');
 if(!verify(null,Buffer.from(JSON.stringify(d)),createPublicKey(key),Buffer.from(envelope.signature??'','base64')))throw Error('Official server directory signature invalid.');
 for(const name of ['server','updateFeed']){const u=new URL(d[name]);if(u.protocol!=='https:'||u.username||u.password||u.hash)throw Error('Official server directory requires HTTPS.');if(name==='server'&&(u.pathname!=='/'||u.search))throw Error('Invalid server origin.');}
 return d;
}
export async function fetchDeploymentEnvelope(url,key){
 const fresh=new URL(url);fresh.searchParams.set('_reborn',Date.now().toString(36));
 try{const envelope=JSON.parse((await download(fresh,16384,{timeout:8000,fresh:true})).toString('utf8'));verifyDeployment(envelope,key);return envelope;}
 catch(primary){
  // Independent GitHub route for networks where the raw-file CDN is unavailable.
  // The same pinned release key must authenticate either response.
  if(new URL(url).origin!=='https://raw.githubusercontent.com'||new URL(url).pathname!=='/alexaa1212ss/game/main/alpha/channel.json')throw primary;
  const mirror=new URL('https://api.github.com/repos/alexaa1212ss/game/contents/alpha/channel.json');mirror.searchParams.set('ref','main');mirror.searchParams.set('_reborn',Date.now().toString(36));
  try{const wrapper=JSON.parse((await download(mirror,32768,{timeout:8000,fresh:true})).toString('utf8'));if(wrapper.encoding!=='base64'||typeof wrapper.content!=='string')throw Error('Invalid directory mirror response.');const envelope=JSON.parse(Buffer.from(wrapper.content,'base64').toString('utf8'));verifyDeployment(envelope,key);return envelope;}
  catch{throw Error('Cannot retrieve the verified Alpha server address from GitHub. Check your connection and reopen the launcher.');}
 }
}
export async function fetchDeployment(url,key){return (await fetchDeploymentEnvelope(url,key)).deployment;}
// Only signed records can change a managed player's destination. Keep the newest
// verified record across launches; a cached CDN response cannot roll it backwards.
export function createDeploymentResolver({url,key,initial,cacheFile,load=()=>fetchDeploymentEnvelope(url,key),now=Date.now}={}){
 let current=initial,lastAttempt=0,pending,error=null;
 const readLatestCache=()=>{if(cacheFile&&existsSync(cacheFile)){try{const saved=verifyDeployment(JSON.parse(readFileSync(cacheFile,'utf8')),key,{now:now()});if(!current||saved.publishedAt>current.publishedAt)current=saved;}catch{}}};readLatestCache();
 const valid=()=>{if(!current||current.expiresAt<=now())throw Error('The official server directory is unavailable or expired. Check your connection and try Play again.');return current;};
 return {get current(){return valid();},get error(){return error;},async refresh({force=false}={}){
  readLatestCache();if(pending)return pending;if(!force&&lastAttempt&&now()-lastAttempt<15000)return valid();lastAttempt=now();
  pending=(async()=>{try{
   const envelope=await load(),next=verifyDeployment(envelope,key,{now:now()});
   // A previous launcher can finish an old request after its replacement has
   // saved the new directory. Re-read before writing so it cannot restore it.
   readLatestCache();
   if(current&&next.publishedAt<current.publishedAt)throw Error('Older server directory ignored.');
   if(current&&next.publishedAt===current.publishedAt&&JSON.stringify(next)!==JSON.stringify(current))throw Error('Conflicting server directory ignored.');
   if(cacheFile)writeJsonAtomic(cacheFile,envelope);current=next;error=null;
  }catch(e){error=e.message;}return valid();})();
  try{return await pending;}finally{pending=null;}
 }};
}
