import {createPublicKey,verify} from 'node:crypto';
import {download} from './update.mjs';
export function verifyDeployment(envelope,key,{now=Date.now()}={}){
 const d=envelope?.deployment;if(!d||d.format!==1||d.product!=='RebornPlayer'||d.protocol!==1||!Number.isSafeInteger(d.expiresAt)||d.expiresAt<=now||d.publishedAt>now+300000)throw Error('Official server directory expired or invalid.');
 if(!verify(null,Buffer.from(JSON.stringify(d)),createPublicKey(key),Buffer.from(envelope.signature??'','base64')))throw Error('Official server directory signature invalid.');
 for(const name of ['server','updateFeed']){const u=new URL(d[name]);if(u.protocol!=='https:'||u.username||u.password||u.hash)throw Error('Official server directory requires HTTPS.');if(name==='server'&&(u.pathname!=='/'||u.search))throw Error('Invalid server origin.');}
 return d;
}
export async function fetchDeployment(url,key){return verifyDeployment(JSON.parse((await download(url,16384)).toString('utf8')),key);}
