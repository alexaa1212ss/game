import http from 'node:http';import {readFile} from 'node:fs/promises';import {existsSync,readFileSync,mkdirSync} from 'node:fs';import path from 'node:path';import {randomBytes} from 'node:crypto';
import {openIdentity,importIdentity} from './identity.mjs';import {ONLINE_PROTOCOL,ONLINE_VERSION} from './constants.mjs';import {writeJsonAtomic} from '../atomic-json.mjs';import {sharedClientAsset} from './client-assets.mjs';
import {packetSchemas} from './client-schemas.mjs';
import {alphaAgreementPolicy,alphaAcceptanceMessage,hasAlphaAcceptance} from './alpha-agreement.mjs';
async function boundedText(response,max=65536){let total=0;const chunks=[];for await(const chunk of response.body){total+=chunk.length;if(total>max)throw Error('Server response exceeds its size limit.');chunks.push(chunk);}return Buffer.concat(chunks).toString('utf8');}
const textType={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf'};
export function validateServerUrl(value){const u=new URL(value);if(u.username||u.password||u.search||u.hash||!['http:','https:'].includes(u.protocol)||u.pathname!=='/')throw Error('Use the HTTPS server address, without paths or credentials.');if(u.protocol==='http:'&&!['127.0.0.1','localhost','[::1]'].includes(u.hostname))throw Error('Remote servers require HTTPS.');return u.origin;}
export async function signIn(base,key,nickname,{alphaAgreement,alphaReceipt}={}){
 const policy=alphaAgreementPolicy(alphaAgreement);
 if(!hasAlphaAcceptance(alphaReceipt,key.id,policy))throw Error('Read and accept the current Closed Alpha agreement before connecting.');
 const request=async(route,body)=>{const response=await fetch(base+route,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(12000),redirect:'error'}),data=JSON.parse(await boundedText(response));if(!response.ok)throw Error(data.error??'Connection failed.');return data;};
 const info=await request('/v1/info');if(info.protocol!==ONLINE_PROTOCOL)throw Error('Server protocol incompatible. Update the client.');
 const remotePolicy=alphaAgreementPolicy(info.alphaAgreement);
 if(remotePolicy&&(!policy||remotePolicy.version!==policy.version||remotePolicy.sha256!==policy.sha256))throw Error('The server requires a different Closed Alpha agreement. Update the client and accept the current agreement.');
 if(policy&&!remotePolicy)throw Error('This Closed Alpha client requires an agreement-enabled server.');
 const c=await request('/v1/auth/challenge',{publicKey:key.publicKey}),message=JSON.parse(c.message);
 if(message.domain!=='cavegame-reborn.login.v1'||message.serverId!==info.serverId||message.audience!==base||message.protocol!==ONLINE_PROTOCOL||message.challengeId!==c.challengeId||message.expiresAt!==c.expiresAt||c.expiresAt<Date.now()-30000||c.expiresAt>Date.now()+90000)throw Error('Server login challenge invalid.');
 if(policy&&(message.alphaAgreement?.version!==policy.version||message.alphaAgreement?.sha256!==policy.sha256))throw Error('Server agreement challenge invalid.');
 return request('/v1/auth/session',{challengeId:c.challengeId,signature:key.sign(c.message),nickname,protocol:ONLINE_PROTOCOL,clientVersion:ONLINE_VERSION,...(policy?{alphaAcceptance:{version:policy.version,sha256:policy.sha256,signature:key.sign(alphaAcceptanceMessage(c.message,policy))}}:{})});
}
export function onlineAsset(filename,text,{endpoint,session,launcherUrl='http://127.0.0.1:33910/'}){
 if(filename==='/index.html'){
  text=text.replace(/<script\b[^>]*src=["']\/world-menu\.js["'][^>]*><\/script>/g,'');
  text=text.replace('</head>','<link rel="stylesheet" href="/online-fidelity.css"><script defer src="/online-fidelity.js"></script></head>');
  const config=JSON.stringify({sessionToken:session.token,account:session.account,version:ONLINE_VERSION,protocol:ONLINE_PROTOCOL,launcherUrl,schemas:packetSchemas}).replaceAll('<','\\u003c');
  return text.replace('<head>','<head><script>window.CavegameRemote='+JSON.stringify({endpoint})+';window.RebornOnline='+config+';</script><script src="/online-guard.js"></script><script src="/online-client.js"></script>');
 }
 if(filename==='/client.local.js')return sharedClientAsset(filename,text,endpoint).replace('data:window.CavegameLocalId','data:JSON.stringify({protocol:window.RebornOnline.protocol,token:window.RebornOnline.sessionToken})').replace('let s=e.data,r=new Uint8Array(s)[0];','let s=e.data;if(!window.RebornOnline.acceptPacket(s)){this.ws.close(1002);return;}let r=new Uint8Array(s)[0];').replace('this.room.ws.onopen=()=>{const t=h().currentUser;',`this.room.ws.onopen=async()=>{try{const r=await fetch('/launcher/refresh-session',{method:'POST'});const a=await r.json();if(!r.ok)throw Error(a.error);window.RebornOnline.sessionToken=a.token;}catch(e){this.serverError=e.message;this.room.leave();this.showDisconnect();return;}const t=h().currentUser;`);
 if(filename==='/local-adapter.js')return text.replace('setupLocalMenu();','window.RebornOnline.menuReady();');
 if(filename==='/player-view.js'&&!session.account.developer)return text.replace('async function loadMap(state,now){',"async function loadMap(state,now){$('pv-status').textContent='Survival: only revealed terrain is streamed';return;");
 return text;
}
export function createOnlineClient({directory,dataDirectory,port=33910,gamePort=port===0?0:33912,protectIdentity,defaultServer='http://127.0.0.1:33901',deployment,updater,onRestart,onQuit,alphaAgreement}={}){
 const publicRoot=path.join(directory,'public');mkdirSync(dataDirectory,{recursive:true});let identity=openIdentity(path.join(dataDirectory,'identity'),{protect:protectIdentity??process.platform==='win32'});
 const settingsFile=path.join(dataDirectory,'settings.json'),settings=existsSync(settingsFile)?JSON.parse(readFileSync(settingsFile,'utf8')):{server:defaultServer,nickname:'Player'};
 const policy=alphaAgreementPolicy(alphaAgreement),agreementFile=path.join(dataDirectory,'alpha-agreement.json');let receipt=null;
 if(existsSync(agreementFile)){try{const saved=JSON.parse(readFileSync(agreementFile,'utf8'));if(saved.format===1)receipt=saved.receipt;}catch{/* A damaged receipt requires fresh, explicit acceptance. */}}
 const accepted=()=>hasAlphaAcceptance(receipt,identity.id,policy),agreementState=()=>({required:!!policy,policy,accepted:accepted(),acceptedAt:accepted()?receipt?.acceptedAt??null:null});
 const requireAgreement=()=>{if(!accepted())throw Error('Read and accept the current Closed Alpha agreement before connecting.');};
 const nonce=randomBytes(24).toString('base64url');let session=null,base=null,lastActivity=Date.now(),agreementRevision=0;
 const endRemoteSession=async(serverBase,previous)=>{if(!previous||!serverBase)return;try{await fetch(serverBase+'/v1/session/end',{method:'POST',headers:{Authorization:'Bearer '+previous.token,'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(3000),redirect:'error'});}catch{}};
 const authenticate=async(next,nickname)=>{const revision=agreementRevision,key=identity,result=await signIn(next,key,nickname,{alphaAgreement:policy,alphaReceipt:receipt});if(revision!==agreementRevision||key!==identity||!accepted()){await endRemoteSession(next,result);throw Error('Launcher access changed. Review the agreement and connect again.');}return result;};
 let server,gameServer;
 const handler=isGame=>async(req,res)=>{
  const reply=(status,value,type='application/json; charset=utf-8')=>{res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; img-src 'self' data: blob:; worker-src 'self' blob:; frame-src 'none'; frame-ancestors 'none'"});res.end(Buffer.isBuffer(value)||typeof value==='string'?value:JSON.stringify(value));};
  try{
   const bound=(isGame?gameServer:server).address()?.port;if(!['127.0.0.1:'+bound,'localhost:'+bound].includes(req.headers.host))return reply(403,{error:'Local host required.'});
   if(req.method!=='GET'&&req.headers.origin!==`http://${req.headers.host}`&&req.headers['x-reborn-launcher']!==nonce)return reply(403,{error:'Local launcher origin required.'});
   const url=new URL(req.url,'http://localhost');let filename=decodeURIComponent(url.pathname);lastActivity=Date.now();
   const launcherUrl='http://127.0.0.1:'+server.address().port+'/',gameUrl='http://127.0.0.1:'+gameServer.address().port;
   if(isGame&&filename.startsWith('/launcher/')&&!['/launcher/heartbeat','/launcher/refresh-session'].includes(filename))return reply(403,{error:'Identity recovery and updates require the separate launcher.'});
   if(isGame&&['/','/launcher'].includes(filename)||!isGame&&['/play','/index.html'].includes(filename)){res.writeHead(303,{Location:isGame?launcherUrl:gameUrl+'/play'});return res.end();}
   const readBody=async()=>{let text='';for await(const b of req){text+=b.toString();if(Buffer.byteLength(text)>65536)throw Error('Request too large.');}return JSON.parse(text||'{}');};
   if(filename==='/health')return reply(200,{ok:true,clientOnly:true,version:ONLINE_VERSION,identityId:identity.id,pid:process.pid});
   if(filename==='/launcher/agreement'&&req.method==='GET')return reply(200,agreementState());
   if(filename==='/launcher/agreement'&&req.method==='POST'){
    const body=await readBody();if(!policy)throw Error('Closed Alpha agreement is not enabled.');
    if(body.version!==policy.version||body.sha256!==policy.sha256||!['accept','decline'].includes(body.decision))throw Error('Choose I AGREE or DECLINE for the current Closed Alpha agreement.');
    const next={accepted:body.decision==='accept',identityId:identity.id,version:policy.version,sha256:policy.sha256,...(body.decision==='accept'?{acceptedAt:Date.now()}:{declinedAt:Date.now()})};
    writeJsonAtomic(agreementFile,{format:1,receipt:next});receipt=next;agreementRevision++;
    if(!next.accepted){const previous=session,previousBase=base;session=null;base=null;await endRemoteSession(previousBase,previous);}
    return reply(200,agreementState());
   }
   if(filename==='/launcher/connect'&&req.method==='POST'){
    requireAgreement();const body=await readBody(),next=validateServerUrl(deployment?.server??body.server),result=await authenticate(next,body.nickname);requireAgreement();session=result;base=next;settings.server=next;settings.nickname=session.account.nickname;writeJsonAtomic(settingsFile,settings);return reply(200,{ok:true,url:gameUrl+'/play',account:session.account});
   }
   if(filename==='/launcher/refresh-session'&&req.method==='POST'){requireAgreement();if(!base)throw Error('Connect through the launcher first.');const result=await authenticate(base,settings.nickname);requireAgreement();session=result;return reply(200,{token:session.token,account:session.account});}
   if(filename==='/launcher/recovery/export'&&req.method==='POST'){const body=await readBody();return reply(200,identity.exportBackup(body.passphrase));}
   if(filename==='/launcher/recovery/import'&&req.method==='POST'){
    const body=await readBody();if(body.confirm!==true)throw Error('Confirm replacing this device identity.');
    if(session&&base){try{const r=await fetch(base+'/v1/self',{headers:{Authorization:'Bearer '+session.token},signal:AbortSignal.timeout(3000)});const state=await r.json();if(state.joined)throw Error('Leave the game before replacing your identity.');}catch(e){if(e.message.includes('Leave the game'))throw e;}}
    const previous=session,previousBase=base;identity=importIdentity(path.join(dataDirectory,'identity'),body.backup,body.passphrase,{protect:protectIdentity??process.platform==='win32'});agreementRevision++;session=null;base=null;await endRemoteSession(previousBase,previous);return reply(200,{ok:true,identityId:identity.id});
   }
   if(filename==='/launcher/heartbeat')return reply(200,{ok:true});
   if(filename==='/launcher/update/check'){if(!updater)throw Error('Updates are available in the packaged client.');return reply(200,await updater.check(deployment?.updateFeed??settings.updateFeed??(settings.server+'/releases/stable.json')));}
   if(filename==='/launcher/update/install'&&req.method==='POST'){if(!updater)throw Error('Packaged client required.');return reply(200,await updater.install(deployment?.updateFeed??settings.updateFeed??(settings.server+'/releases/stable.json')));}
   if(filename==='/launcher/update/rollback'&&req.method==='POST'){if(!updater)throw Error('Packaged client required.');return reply(200,updater.rollback());}
   if(filename==='/launcher/restart'&&req.method==='POST'){if(!onRestart)throw Error('Restart through the desktop launcher.');reply(200,{ok:true,pid:process.pid});setTimeout(onRestart,200).unref();return;}
   if(filename==='/launcher/quit'&&req.method==='POST'){if(!onQuit)throw Error('Close the desktop client.');reply(200,{ok:true});setTimeout(onQuit,200).unref();return;}
   if(filename.startsWith('/v1/')||filename.startsWith('/local/')){
    requireAgreement();
    if(!session||!base)throw Error('Connect through the launcher first.');
    const route=filename==='/local/diagnostics'?'/v1/diagnostics':filename;
    const body=req.method==='POST'?JSON.stringify(await readBody()):undefined;
    const response=await fetch(base+route+url.search,{method:req.method,headers:{Authorization:'Bearer '+session.token,'Content-Type':'application/json'},body,signal:AbortSignal.timeout(30000),redirect:'error'});return reply(response.status,await boundedText(response,16*1024*1024));
   }
   if(filename==='/cavegame-io-servers')return reply(200,{states:[{title:'REBORN ONLINE',ip:base?.replace('http','ws')+'/ws',playerCount:'?',best:true}]});
   if(filename==='/event-info')return reply(200,'false','text/plain');
   if(filename==='/'||filename==='/launcher'){
    let page=await readFile(path.join(publicRoot,'online-launcher.html'),'utf8');const config=JSON.stringify({nonce,settings:{...settings,...(deployment?{server:deployment.server,updateFeed:deployment.updateFeed}:{})},managed:!!deployment,version:ONLINE_VERSION,identityId:identity.id,alphaAgreement:agreementState()}).replaceAll('<','\\u003c');page=page.replace('/*LAUNCHER_CONFIG*/','window.RebornLauncher='+config+';');return reply(200,page,'text/html; charset=utf-8');
   }
   if(filename==='/play'){requireAgreement();if(!session||session.expiresAt<=Date.now())throw Error('Sign in through the launcher again.');filename='/index.html';}
   if(filename==='/index.html')requireAgreement();
   if(filename==='/index.html'&&!session)throw Error('Use the launcher first.');
   if(!isGame&&filename!=='/online-launcher.js'&&!['.css','.png','.svg','.ico','.woff','.woff2','.ttf'].includes(path.extname(filename)))return reply(403,{error:'Game assets use the separate game origin.'});
   const resolved=path.resolve(publicRoot,'.'+filename);if(!resolved.startsWith(publicRoot+path.sep))return reply(403,{error:'Invalid asset path.'});
   let data=await readFile(resolved);if(session&&['/index.html','/client.local.js','/local-adapter.js','/player-view.js'].includes(filename))data=Buffer.from(onlineAsset(filename,data.toString(),{endpoint:base.replace('http','ws')+'/ws',session,launcherUrl}));
   return reply(200,data,textType[path.extname(filename)]??'application/octet-stream');
  }catch(e){reply(e.code==='ENOENT'?404:/agreement before connecting/i.test(e.message)?403:400,{error:e.message});}
 };
 server=http.createServer(handler(false));gameServer=http.createServer(handler(true));
 return {server,gameServer,get identity(){return identity;},nonce,settings,start:async()=>{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});try{await new Promise((resolve,reject)=>{gameServer.once('error',reject);gameServer.listen(gamePort,'127.0.0.1',resolve);});}catch(e){await new Promise(r=>server.close(r));throw e;}},stop:()=>Promise.all([new Promise(r=>server.close(r)),new Promise(r=>gameServer.close(r))]),lastActivity:()=>lastActivity};
}
