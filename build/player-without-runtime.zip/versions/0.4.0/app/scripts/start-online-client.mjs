import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';import {existsSync} from 'node:fs';import {spawn} from 'node:child_process';
import {createOnlineClient} from '../src/online/client.mjs';import {ReleaseUpdater} from '../src/online/update.mjs';
import {CLOSED_ALPHA_AGREEMENT} from '../src/online/alpha-agreement.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),dataDirectory=process.env.CAVEGAME_CLIENT_DATA??path.join(process.env.LOCALAPPDATA??os.homedir(),'CavegameReborn');
const port=Number(process.env.CAVEGAME_CLIENT_PORT??33930),gamePort=Number(process.env.CAVEGAME_GAME_PORT??33932),url='http://127.0.0.1:'+port+'/';
const open=()=>{const edge=path.join(process.env['ProgramFiles(x86)']??'C:\\Program Files (x86)','Microsoft/Edge/Application/msedge.exe');if(existsSync(edge))spawn(edge,['--app='+url],{stdio:'ignore',detached:true,windowsHide:false}).unref();else spawn('explorer.exe',[url],{stdio:'ignore',detached:true,windowsHide:true}).unref();};
let existing;try{existing=await(await fetch(url+'health',{signal:AbortSignal.timeout(700)})).json();}catch{}
if(existing?.clientOnly){if(!process.argv.includes('--no-browser'))open();process.exit(0);}
const deployment=JSON.parse(process.env.CAVEGAME_PLAYER_DEPLOYMENT),updater=new ReleaseUpdater({directory:process.env.CAVEGAME_INSTALL_ROOT,product:'RebornPlayer'});
let idle;const quit=async()=>{clearInterval(idle);await client.stop();process.exit(0);};
const restart=async()=>{await client.stop();clearInterval(idle);const install=process.env.CAVEGAME_INSTALL_ROOT,version=updater.current().current;spawn(path.join(install,'versions',version,'runtime/node.exe'),[path.join(install,'bootstrap.mjs'),install,'client'],{stdio:'ignore',detached:true,windowsHide:true}).unref();process.exit(0);};
const client=createOnlineClient({directory:root,dataDirectory,port,gamePort,defaultServer:deployment.server,deployment,updater,onQuit:quit,onRestart:restart,alphaAgreement:CLOSED_ALPHA_AGREEMENT});await client.start();
if(!process.argv.includes('--no-browser'))open();idle=setInterval(()=>{if(Date.now()-client.lastActivity()>90000)quit();},15000);
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,quit);
