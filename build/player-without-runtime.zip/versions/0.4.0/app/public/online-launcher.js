(() => {
 const config=window.RebornLauncher,$=id=>document.getElementById(id);$('server').value=config.settings.server;$('nickname').value=config.settings.nickname;$('version').textContent='Reborn Online '+config.version;$('identity').textContent='Identity: '+config.identityId;
 const request=async(route,body)=>{const r=await fetch(route,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','x-reborn-launcher':config.nonce},body:body?JSON.stringify(body):undefined});const data=await r.json();if(!r.ok)throw Error(data.error);return data;};
 let agreement=config.alphaAgreement??{required:false,accepted:true},reviewing=false,agreementBusy=false;
 const agreementBlocked=()=>agreement.required&&!agreement.accepted;
 function showAgreement(){
  const required=agreement.required,policy=agreement.policy;$('alpha-agreement').hidden=!required||agreement.accepted&&!reviewing;$('alpha-review').hidden=!required||!agreement.accepted;$('alpha-status').hidden=!required;$('connect-fields').disabled=agreementBlocked()||agreementBusy;
  if(!required)return;
  $('alpha-title').textContent=policy.title;$('alpha-version').textContent='Agreement version: '+policy.version;
  $('alpha-copy').replaceChildren(...policy.paragraphs.map(text=>{const p=document.createElement('p');p.textContent=text;return p;}));
  $('alpha-status').textContent=agreement.accepted?'Closed Alpha agreement accepted. Your acceptance is saved for this identity.':'Play remains locked until you choose I AGREE.';
  $('alpha-accept').disabled=agreementBusy;$('alpha-decline').disabled=agreementBusy;
 }
 $('alpha-review').onclick=()=>{reviewing=true;showAgreement();$('alpha-title').scrollIntoView({block:'nearest'});};
 async function chooseAgreement(decision){
  if(!agreement.required||agreementBusy)return;agreementBusy=true;showAgreement();$('alpha-feedback').textContent='Saving your choice…';
  try{agreement=await request('/launcher/agreement',{decision,version:agreement.policy.version,sha256:agreement.policy.sha256});reviewing=false;$('alpha-feedback').textContent=decision==='accept'?'Agreement accepted.':'You declined the agreement. Alpha access is disabled.';$('feedback').textContent=decision==='accept'?'Ready to connect.':'Alpha access is disabled. You may review the agreement again.';}
  catch(error){$('alpha-feedback').textContent=error.message;}
  finally{agreementBusy=false;showAgreement();if(agreement.accepted)$('nickname').focus();}
 }
 $('alpha-accept').onclick=()=>chooseAgreement('accept');$('alpha-decline').onclick=()=>chooseAgreement('decline');showAgreement();
 $('connect').onsubmit=async e=>{e.preventDefault();if(agreementBlocked()||agreementBusy){$('feedback').textContent='Read the Closed Alpha agreement and choose I AGREE to play.';return;}const button=e.target.querySelector('button');button.disabled=true;$('feedback').textContent='Connecting securely…';try{const result=await request('/launcher/connect',{server:$('server').value,nickname:$('nickname').value});location.href=result.url;}catch(error){$('feedback').textContent=error.message;}finally{button.disabled=agreementBlocked()||agreementBusy;}};
 $('check-update').onclick=async()=>{try{const result=await request('/launcher/update/check');$('update-state').textContent=result.available?'Update '+result.version+' available.':result.message||'You have the latest version.';$('install-update').hidden=!result.available;}catch(error){$('update-state').textContent=error.message;}};
 $('install-update').onclick=async()=>{const button=$('install-update');button.disabled=true;$('update-state').textContent='Verifying and installing update…';try{const result=await request('/launcher/update/install',{});$('update-state').textContent=result.message||'Installed.';$('restart-client').hidden=false;}catch(error){$('update-state').textContent=error.message;}finally{button.disabled=false;}};
 $('rollback').onclick=async()=>{try{const result=await request('/launcher/update/rollback',{});$('update-state').textContent=result.message;$('restart-client').hidden=false;}catch(error){$('update-state').textContent=error.message;}};
 $('restart-client').onclick=async()=>{try{const previous=await request('/launcher/restart',{});$('update-state').textContent='Restarting…';let attempts=0;const poll=setInterval(async()=>{try{const r=await fetch('/health');if(r.ok&&(await r.json()).pid!==previous.pid){clearInterval(poll);location.reload();}}catch{}if(++attempts>30){clearInterval(poll);$('update-state').textContent='Reopen Reborn Client.exe to finish restarting.';}},1000);}catch(error){$('update-state').textContent=error.message;}};
 $('export-recovery').onclick=async()=>{try{const result=await request('/launcher/recovery/export',{passphrase:$('recovery-pass').value});const url=URL.createObjectURL(new Blob([JSON.stringify(result,null,2)],{type:'application/json'})),link=document.createElement('a');link.href=url;link.download='Reborn-identity-recovery.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);$('recovery-pass').value='';$('feedback').textContent='Encrypted recovery key exported. Keep its passphrase separately.';}catch(error){$('feedback').textContent=error.message;}};
 $('import-recovery').onclick=async()=>{try{const file=$('recovery-file').files[0];if(!file||file.size>4096)throw Error('Choose a valid recovery file.');if(!confirm('Replace this PC identity with the recovery identity? The previous local key is retained as a backup.'))return;await request('/launcher/recovery/import',{backup:JSON.parse(await file.text()),passphrase:$('recovery-pass').value,confirm:true});location.reload();}catch(error){$('feedback').textContent=error.message;}};
 setInterval(()=>fetch('/launcher/heartbeat').catch(()=>{}),10000);
})();
