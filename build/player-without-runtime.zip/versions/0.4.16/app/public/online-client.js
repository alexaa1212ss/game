(() => {
 const online=window.RebornOnline;
 online.menuReady=()=>{
  document.body.classList.add('reborn-online');
  document.title='Cavegame Reborn Online';const note=document.getElementById('local-notice');if(note)note.textContent='SURVIVAL · Server-saved progress'+' · F6 Community';
  localStorage.setItem('nickname',online.account.nickname);const nickname=document.getElementById('nickname');if(nickname){nickname.maxLength=20;nickname.value=online.account.nickname;nickname.readOnly=true;}
  for(const id of ['sign-in-google','sign-out-google','sign-in-game-text','secret-ip-container','ranks']){const e=document.getElementById(id);if(e)e.style.display='none';}
  const left=document.querySelector('#menu-table td:first-child .mini-modal');if(left){const h=document.createElement('h3'),p=document.createElement('p');h.textContent='REBORN ONLINE '+online.version;p.textContent='One shared world. Your progress saves automatically. F6 opens clans, leaderboards and your account.';left.replaceChildren(h,p);}
  const links=document.getElementById('bottom-links');if(links){const a=document.createElement('a');a.href=online.launcherUrl;a.textContent='Reborn Launcher · Updates · Identity Recovery';links.replaceChildren(a);}
  const info=document.getElementById('important-server-info');if(info)info.textContent='Online identity verified · '+online.account.nickname+' · '+online.account.rank;
  const form=document.querySelector('#menu-table form');if(form){const p=document.createElement('p');p.textContent=online.account.developer?'Developer permissions verified by the server. /devhelp':'Connected as '+online.account.nickname+'. Your nickname and inventory are server-controlled.';const back=document.createElement('a');back.href=online.launcherUrl;back.textContent='Launcher / Updates / Recovery';form.append(p,back);}
  if(!online.account.developer&&window.CavegameClient){window.CavegameClient.setXray(false);const previous=window.CavegameClient.setXray;window.CavegameClient.setXray=value=>previous(false);}
 };
 document.addEventListener('DOMContentLoaded',()=>{
  const style=document.createElement('link');style.rel='stylesheet';style.href='/online.css';document.head.append(style);
  const button=document.createElement('button');button.type='button';button.className='ro-community-open';button.textContent='Community [F6]';
  const panel=document.createElement('section');panel.className='ro-panel';panel.hidden=true;panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label','Online community');
  panel.innerHTML='<header><h2>REBORN ONLINE</h2><button id="ro-close">Close [Esc]</button></header><nav id="ro-tabs"></nav><div id="ro-content"></div><output id="ro-feedback"></output>';
  document.body.append(button,panel);const $=id=>document.getElementById(id),tabs=[['leaderboards','Leaderboards'],['clans','Clans'],['identity','My identity']];let tab='leaderboards',busy=false;
  const request=async(route,body)=>{const r=await fetch(route,{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});const value=await r.json();if(!r.ok)throw Error(value.error||'Action failed');return value;};
  function table(rows,columns){const table=document.createElement('table'),head=document.createElement('tr');for(const [,label]of columns){const th=document.createElement('th');th.textContent=label;head.append(th);}table.append(head);for(const row of rows){const tr=document.createElement('tr');for(const [key]of columns){const td=document.createElement('td');td.textContent=row[key]??'—';tr.append(td);}table.append(tr);}return table;}
  function actionButton(label,callback){const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=async()=>{if(busy)return;busy=true;b.disabled=true;try{await callback();$('ro-feedback').textContent='Saved on server.';await render();}catch(e){$('ro-feedback').textContent=e.message;}finally{busy=false;b.disabled=false;}};return b;}
  async function render(){
   $('ro-content').replaceChildren();for(const b of $('ro-tabs').children)b.setAttribute('aria-pressed',String(b.dataset.tab===tab));const content=$('ro-content');
   try{
    if(tab==='leaderboards'){const data=await request('/v1/leaderboards');for(const [key,title,field]of [['kills','PvP — kills','kills'],['mining','Mining — blocks','blocksMined'],['gold','Gold Empire — lifetime gold','lifetimeGold']]){const h=document.createElement('h3');h.textContent=title+' · Top 10';content.append(h,table((data[key]??[]).slice(0,10),[['nickname','Player'],['clan','Clan'],[field,'Score']]));}}
    else if(tab==='identity'){const self=await request('/v1/self'),card=document.createElement('div');card.className='ro-card';card.textContent=self.nickname+' · '+self.rank+' · '+self.id;content.append(card);for(const warning of self.warnings??[]){const p=document.createElement('p');p.textContent='Warning: '+warning.reason;content.append(p);}}
    else if(tab==='clans'){
     const data=await request('/v1/clans');if(data.clan){const card=document.createElement('div');card.className='ro-card';card.textContent='['+data.clan.tag+'] '+data.clan.name+' · '+data.clan.members.length+'/20 members';content.append(card);
      const target=document.createElement('input');target.placeholder='Player nickname';content.append(target,actionButton('Invite',()=>request('/v1/clans',{action:'invite',target:target.value})),actionButton('Leave clan',()=>request('/v1/clans',{action:'leave'})));
     }else{const tag=document.createElement('input'),name=document.createElement('input');tag.placeholder='Tag (2–8)';tag.maxLength=8;name.placeholder='Clan name';name.maxLength=32;content.append(tag,name,actionButton('Create clan',()=>request('/v1/clans',{action:'create',tag:tag.value,name:name.value})));}
     for(const invite of data.invites)content.append(actionButton('Join ['+invite.tag+']',()=>request('/v1/clans',{action:'accept',clanId:invite.id})));
     content.append(table(data.clans,[['tag','Tag'],['name','Clan'],['members','Members']]));
    }

   }catch(e){$('ro-feedback').textContent=e.message;}
  }
  for(const [id,label]of tabs){const b=document.createElement('button');b.textContent=label;b.dataset.tab=id;b.onclick=()=>{tab=id;render();};$('ro-tabs').append(b);}
  const close=()=>{panel.hidden=true;window.CavegameUI?.close('online-community');if(!window.CavegameUI)document.activeElement?.blur();request('/local/action',{action:'menu',open:false}).catch(()=>{});};
  const open=()=>{panel.hidden=false;window.CavegameUI?.open('online-community');request('/local/action',{action:'menu',open:true}).catch(()=>{});render();};
  window.CavegameUI?.register('online-community',{element:panel,close,returnFocus:'game'});button.onclick=open;$('ro-close').onclick=close;
  // Anchor underneath the existing Gold Empire button, including responsive changes.
  // Never move the native leaderboard, EXP bar, or the Gold Empire control itself.
  let watchedEmpire=null,positionFrame=0;
  const place=()=>{cancelAnimationFrame(positionFrame);positionFrame=requestAnimationFrame(()=>{const empire=$('empire-launch');if(!empire||empire.hidden)return;const r=empire.getBoundingClientRect();if(!r.width||!r.height)return;button.style.left=Math.max(8,Math.min(r.left,innerWidth-button.offsetWidth-8))+'px';button.style.top=(r.bottom+6)+'px';});};
  const attach=()=>{const empire=$('empire-launch');if(!empire||empire===watchedEmpire)return;watchedEmpire=empire;if(typeof ResizeObserver==='function')new ResizeObserver(place).observe(empire);new MutationObserver(place).observe(empire,{attributes:true,attributeFilter:['hidden','class','style']});place();};
  const finder=new MutationObserver(()=>{attach();if(watchedEmpire)finder.disconnect();});finder.observe(document.body,{childList:true});attach();window.addEventListener('resize',place);
  window.addEventListener('keydown',e=>{if(e.code==='F6'){e.preventDefault();panel.hidden?open():close();}});
  setInterval(()=>fetch('/launcher/heartbeat').catch(()=>{}),10000);
 });
})();
